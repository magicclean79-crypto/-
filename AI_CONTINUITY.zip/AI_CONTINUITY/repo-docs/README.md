# AI Product Content OS

> **`v1.0.0-rc.1`** — Release Candidate. 정식 `v1.0.0`은 **아직
> 붙이지 않았습니다.**
>
> 실 Provider Validation을 **한 번도 돌린 적이 없습니다**
> (`validation_runs` **0건**) — 실패가 아니라 **시작하지 못한 것**입니다.
> 남은 것은 사람이 준비해야 하는 7항목이며
> [`RELEASE_CHECKLIST.md`](RELEASE_CHECKLIST.md)로 관리합니다.
>
> 최종 판단 [`reports/CTO_FINAL_RELEASE_REPORT.md`](reports/CTO_FINAL_RELEASE_REPORT.md) ·
> 막는 것 [`reports/RELEASE_BLOCKER_REPORT.md`](reports/RELEASE_BLOCKER_REPORT.md) ·
> Go-Live 판정 [`reports/GO_LIVE_REPORT.md`](reports/GO_LIVE_REPORT.md)
>
> rc.1 태그는 커밋 `5b04dc3`에 만들었으나 이 환경의 git 게이트웨이가 태그
> ref 푸시를 **403**으로 막아 원격에 없습니다
> ([`RELEASE_READINESS.md`](RELEASE_READINESS.md)).
>
> 처음이면 [`USER_GUIDE.md`](USER_GUIDE.md) · 세우려면
> [`MIGRATION_GUIDE.md`](MIGRATION_GUIDE.md) · 당직 중이면
> [`OPERATIONS_RUNBOOK.md`](OPERATIONS_RUNBOOK.md) · 안 되는 것은
> [`KNOWN_LIMITATIONS.md`](KNOWN_LIMITATIONS.md).

AI 기반 제품 콘텐츠 운영 시스템(Monorepo)입니다. pnpm + Turborepo로 관리됩니다.

## 프로젝트 구조

```
ai-product-content-os/
 ├─ apps/
 │   ├─ web            # Next.js (TypeScript, Tailwind CSS) — http://localhost:3000
 │   └─ api            # NestJS + Prisma — http://localhost:4000
 ├─ packages/
 │   ├─ core           # 도메인 로직 (@acos/core)
 │   ├─ shared         # 공용 타입/유틸/상수 (@acos/shared)
 │   ├─ agents         # AI 에이전트 (@acos/agents)
 │   └─ ui             # 공용 React UI 컴포넌트 (@acos/ui)
 ├─ docs               # 문서
 ├─ infrastructure     # 인프라 구성 (Docker, IaC)
 ├─ scripts            # 운영/개발 스크립트
 ├─ tests              # 통합/E2E 테스트
 ├─ docker-compose.yml # PostgreSQL, Redis, MinIO
 └─ turbo.json
```

## 요구 사항

- Node.js >= 20
- pnpm >= 10 (`corepack enable` 권장)
- Docker (PostgreSQL / Redis / MinIO 실행용)

## 시작하기

```bash
# 1. 의존성 설치
pnpm install

# 2. (선택) 인프라 실행 — PostgreSQL, Redis, MinIO
pnpm docker:up

# 3. (선택) 환경 변수 설정
cp .env.example apps/api/.env

# 4. 개발 서버 실행 (web + api 동시 실행)
pnpm dev
```

- Web: <http://localhost:3000>
- API Health: <http://localhost:4000/health> → `OK`
- MinIO Console: <http://localhost:9001> (minioadmin / minioadmin)

> DB가 실행 중이 아니어도 web/api는 정상 기동됩니다. Prisma 마이그레이션 등 DB 작업 시에만 `pnpm docker:up`이 필요합니다.

## 주요 명령어

| 명령어 | 설명 |
| --- | --- |
| `pnpm dev` | web + api + 패키지 watch 동시 실행 |
| `pnpm build` | 전체 빌드 (Turborepo 캐시 적용) |
| `pnpm lint` | 전체 린트 |
| `pnpm test` | 전체 테스트 (Jest — unit/service/API) |
| `pnpm docker:up` / `pnpm docker:down` | 인프라 기동 / 종료 |
| `pnpm prisma:generate` | Prisma Client 생성 |
| `pnpm prisma:migrate` | DB 마이그레이션 (`prisma migrate dev`) |
| `pnpm prisma:studio` | Prisma Studio 실행 |

## 사진 업로드 (TASK-0201)

- 업로드 화면: <http://localhost:3000/upload> — 드래그 앤 드롭, 다중 업로드, 진행률 표시
- 저장소: MinIO 버킷 `acos` (`images/{yyyy}/{mm}/{uuid}.{ext}` 키로 저장, public-read)
- 메타데이터: PostgreSQL `images` 테이블 (Prisma `Image` 모델)

### 업로드 API

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/uploads/images` | `multipart/form-data`, 필드명 `files` (최대 10개, 파일당 10MB, jpeg/png/webp/gif) |
| `GET` | `/uploads/images?take=20` | 최근 업로드 목록 |

성공 응답(201):

```json
{
  "images": [
    {
      "id": "cml…",
      "key": "images/2026/07/….jpg",
      "url": "http://localhost:9000/acos/images/2026/07/….jpg",
      "originalName": "photo.jpg",
      "mimeType": "image/jpeg",
      "size": 123456,
      "productId": null,
      "createdAt": "2026-07-27T00:00:00.000Z"
    }
  ]
}
```

오류: `400` 파일 없음/형식 불일치, `413` 10MB 초과, `503` MinIO/DB 연결 불가.

## OCR (TASK-0202)

교체 가능한 Provider 아키텍처 위에서 이미지 텍스트를 추출합니다.
도메인(인터페이스·상태 전이·재시도)은 `@acos/core`에 있으며, 자세한 구조와
Google Vision/Azure 연결 방법은 [docs/architecture/ocr.md](docs/architecture/ocr.md) 참고.

- Provider 선택: `OCR_PROVIDER` — `mock`(기본, 실제 OCR 미연결) | `tesseract`(로컬 엔진)
- 상태: `PENDING → RUNNING → SUCCESS | FAILED`
- 실행마다 결과가 이력으로 쌓입니다 (Image : OCRResult = **1:N**)
- 실패 시 지수 백오프로 최대 `OCR_MAX_ATTEMPTS`(기본 3)회 재시도
- `confidence`(0.0~1.0), `extractedText`, Provider 원본 응답(`rawJson`) 저장

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/images/:imageId/ocr` | OCR 실행 — 새 실행 레코드 생성 (재실행 = 다시 호출) |
| `GET` | `/images/:imageId/ocr?raw=true` | 최신 결과 조회 (`raw=true`면 원본 JSON 포함) |
| `GET` | `/images/:imageId/ocr/history` | 실행 이력 (최신순) |
| `GET` | `/ocr/results?take=20` | 최근 결과 목록 |

## Product Object (TASK-0203)

OCR·Vision 결과를 조립한 **핵심 데이터 모델**입니다. 프로젝트(현재는 Product 단위)별로
버전 관리되며, 향후 상세페이지 생성의 단일 진실 공급원이 됩니다.
구조: [docs/architecture/product-object.md](docs/architecture/product-object.md) ·
스키마: [docs/schema/product-object.schema.json](docs/schema/product-object.schema.json)

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/projects/:projectId/product-object` | OCR+Vision(LLM 기반) 조립 → 새 버전 생성 |
| `GET` | `/projects/:projectId/product-object?version=N` | 최신(또는 특정) 버전 조회 |
| `GET` | `/projects/:projectId/product-object/history` | 버전 이력 |
| `PATCH` | `/projects/:projectId/product-object/:version/status` | 상태 전이 (`DRAFT ⇄ READY`, `→ ARCHIVED`; READY는 검증 통과 필요) |

- 상태: `DRAFT → READY → ARCHIVED` · 버전: `projectId+version` 유니크, 생성마다 증가
- Vision: **LLM 기반 멀티모달 공식 엔진**(TASK-0505)이 visionSummary 공급 — 이미지
  바이트(base64, 최대 5장) + Prompt Engine(`vision-analysis`) + LLM Gateway +
  Company Brain 사용, 모델 선택은 `LLM_PROVIDER` 하나(기본 mock, 실패 시 null 폴백)
  — [docs/architecture/vision.md](docs/architecture/vision.md)
- **Image Guard & Preprocessing (TASK-0604)**: Vision 호출 전 검증(MIME/용량) →
  리사이즈(최대 1024px) → 최적화(JPEG q82) → **EXIF 제거** → 출력 5MB 제한 —
  위반 이미지는 스킵(분석 계속), 정책은 `VISION_IMAGE_*` 환경변수로 조정

## AI 분석 (TASK-0204 · TASK-0504에서 LLM 기반 엔진으로 교체)

상품 이미지의 OCR 텍스트 + Company Brain에서 구조화된 상품 정보(이름·카테고리·키워드·
설명·속성·신뢰도)를 추출합니다. 공식 엔진은 **Prompt Engine(`product-analysis` 템플릿) +
LLM Gateway + Company Brain**을 사용하는 `LlmAnalysisProvider`입니다 — 모델 선택은
`LLM_PROVIDER` 환경 변수 하나로 관리(기본 mock, 실제 API 미호출).
자세한 구조: [docs/architecture/analysis.md](docs/architecture/analysis.md)

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/products/:productId/analysis` | 분석 실행. body `{ "apply": true }`면 결과를 상품 name/description에 반영 |
| `GET` | `/products/:productId/analysis?raw=true` | 최신 결과 조회 |
| `GET` | `/products/:productId/analysis/history` | 실행 이력 (최신순) |

- 상태: `PENDING → RUNNING → SUCCESS | FAILED`, Product : AnalysisResult = **1:N** 이력
- 실패 시 지수 백오프 재시도 (`ANALYSIS_MAX_ATTEMPTS`, 기본 3)

## Project (TASK-0301)

최상위 루트 엔티티입니다. 여러 상품과 Product Object 버전 이력을 묶는 작업 단위이며,
상품 생성 시 `projectId`를 지정하거나(미지정 시 자동 생성) 프로젝트를 직접 관리할 수 있습니다.

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/projects` | `{ name, description? }` 프로젝트 생성 |
| `GET` | `/projects?take=20` | 목록 (상품 수·Product Object 수 포함) |
| `GET` | `/projects/:id` | 상세 (상품 목록 + 최신 Product Object 버전) |
| `PATCH` | `/projects/:id` | 수정 |
| `DELETE` | `/projects/:id` | 삭제 (상품·Product Object 함께 삭제, 이미지는 연결 해제) |

웹: `/projects`(목록) · `/projects/[id]`(파이프라인 실행 — 조립 → READY 전환 → 상세페이지 생성)

## 상세페이지 콘텐츠 (TASK-0303 · TASK-0502 · TASK-0506 통합)

READY 상태의 Product Object를 단일 입력으로 상세페이지(Markdown)를 생성합니다.

- **엔진 경로 (TASK-0502)**: READY Product Object + **Company Brain**(지식·결정·설정·금지어) +
  **LLM Gateway**로 생성 — [docs/architecture/content-generation.md](docs/architecture/content-generation.md)
- 구 경로 (TASK-0303): **TASK-0506에서 내부가 공식 엔진으로 통합** — 계약은 유지되고
  Wrapper(EngineContentGenerator)가 같은 생성 코어를 호출, 두 경로의 본문 동일 —
  [docs/architecture/content.md](docs/architecture/content.md)

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/projects/:projectId/contents/generate` | **공식 생성 엔진** (CTO 결정) — `{ productObjectVersion? }`, 미지정 시 최신 READY. 웹 버튼도 이 경로 사용 |
| `POST` | `/projects/:projectId/contents` | ⚠️ Deprecated — 구 경로, 내부는 공식 엔진 호출 (TASK-0506 통합 완료) |
| `GET` | `/projects/:projectId/contents` | 목록 |
| `GET` | `/projects/:projectId/contents/:contentId` | 단건 |
| `PATCH` | `/projects/:projectId/contents/:contentId/status` | **발행 파이프라인 (TASK-0703)** — `DRAFT → REVIEW → PUBLISHED → ARCHIVED`, PUBLISHED는 발행 조건 검증 + publishedAt(최초 발행 시점 보존) |
| `GET` | `/projects/:projectId/contents/:contentId/history` | **감사 이력 (TASK-0704)** — 상태 전이 기록(from→to·시각, 최신순) |

운영: **실제 Provider 스모크 테스트 (TASK-0703)** — `node scripts/real-provider-smoke.mjs`
(운영/스테이징 실키 환경 절차: [docs/operations/real-provider-smoke.md](docs/operations/real-provider-smoke.md))

## 인증/권한 (TASK-0801 Foundation · 0802 전면 쓰기 보호 · 0803 비밀번호/운영 보안 · 0804 로그인 보호)

User Entity(역할 ADMIN/EDITOR/VIEWER) · DB 세션(Bearer+httpOnly 쿠키, 7일) ·
RBAC · Actor Audit · **Login UI**(`/login`) · **사용자 관리 UI**(`/admin/users`) ·
**내 계정**(`/account`) — [docs/architecture/auth.md](docs/architecture/auth.md)

| 메서드 | 경로 | 보호 |
| --- | --- | --- |
| `POST` | `/auth/login` | 공개 — `{ email, password }` → 세션 토큰 + httpOnly 쿠키 |
| `POST` | `/auth/logout` · `GET /auth/me` | 인증 |
| `PATCH` | `/auth/password` | 인증(모든 역할) — 본인 비밀번호 변경, 다른 세션 폐기 |
| `GET/POST` | `/auth/users` · `PATCH /auth/users/:id` · `POST /auth/users/:id/password-reset` · `GET /auth/audit` | **ADMIN** — 목록/생성/역할 변경/비활성화/비밀번호 재설정 + 감사 로그 |

- **모든 쓰기 API(POST/PATCH/PUT/DELETE)는 EDITOR 이상 인증 필요** (TASK-0802,
  전역 가드). 예외: 로그인·Company Brain 조회·READY 검증(읽기 성격 @Public —
  CTO 확정, 이 3종만 유지). 조회 GET은 비보호(CTO 결정)
- **`/llm/health`는 운영/스테이징(NODE_ENV 또는 `AUTH_PROTECT_HEALTH=1`)에서
  EDITOR 이상** — 개발은 비보호 (CTO 결정 0802-③)
- **쿠키 세션(운영)**: Bearer 우선, 없으면 `acos_session` httpOnly 쿠키 인식.
  `AUTH_COOKIE_SECURE=1`(운영 필수) · `AUTH_COOKIE_SAMESITE=lax|strict|none` ·
  **`AUTH_COOKIE_ONLY`(운영 기본 켜짐 — 본문 토큰 제외, 쿠키 전용)**
- **로그인 보호 (TASK-0804)**: Rate Limit(`AUTH_LOGIN_MAX_ATTEMPTS`/`AUTH_LOGIN_WINDOW_SEC`,
  기본 30회/60초 → 429) · 계정 잠금(`AUTH_LOCKOUT_THRESHOLD`/`AUTH_LOCKOUT_MINUTES`,
  기본 5회/15분 — 재설정 시 즉시 해제) · 비밀번호 복잡도(8자+영문+숫자) ·
  실패/잠금 감사(LOGIN_FAILED/ACCOUNT_LOCKED) · 세션 TTL(`AUTH_SESSION_TTL_HOURS`, 기본 168)
- 발행 전이 수행자는 감사 이력 actor에, 사용자 관리·비밀번호
  변경/재설정은 user_audit_log에 기록
- 최초 기동 시 사용자 0명이면 관리자 자동 생성 (`AUTH_ADMIN_EMAIL`/`AUTH_ADMIN_PASSWORD`,
  기본 admin@acos.local / admin1234 — 로컬 전용)
- 스모크 스크립트는 `SMOKE_EMAIL`/`SMOKE_PASSWORD`로 로그인 후 실행

## SOP 실행 (TASK-0305)

SOP는 회사의 표준 업무 절차를 저장하는 도메인(Company Brain)이고,
실행은 Execution Layer의 **Workflow Engine**이 담당합니다. 기본 SOP
`product-content`는 기존 파이프라인(OCR → 조립 → READY 검수 → 상세페이지)을
한 번의 호출로 실행하며, 실행마다 단계별 결과가 이력으로 남습니다
(Project : SopRun = 1:N) — [docs/architecture/sop.md](docs/architecture/sop.md)

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/projects/:projectId/sop-runs` | 기본 SOP 실행 → 실행 이력 반환 (단계 실패 시 `status: FAILED` 이력) |
| `GET` | `/projects/:projectId/sop-runs` | 실행 이력 목록 (최신순) |
| `GET` | `/projects/:projectId/sop-runs/:runId` | 실행 단건 조회 |

- 단계 상태: `PENDING → RUNNING → DONE | FAILED` (실패 시 이후 단계 `SKIPPED`)
- 단계 간 데이터 전달: 조립 단계의 버전이 READY 검수·상세페이지 생성에 사용됨

## Decision Log (TASK-0306)

프로젝트 진행 중 내린 의사결정(무엇을·왜)을 기록합니다. Company Brain의 일부로
SOP와 나란히 회사 지식을 축적합니다 — [docs/architecture/decision.md](docs/architecture/decision.md)

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/projects/:projectId/decisions` | `{ title, description?, reason, decisionType, author }` 생성 |
| `GET` | `/projects/:projectId/decisions` | 목록 (최신순) |
| `GET` | `…/decisions/:decisionId` | 단건 |
| `PATCH` | `…/decisions/:decisionId` | 부분 수정 |
| `DELETE` | `…/decisions/:decisionId` | 삭제 (204) |

- `decisionType`(Enum): `ARCHITECTURE · PROCESS · PRODUCT · BUSINESS · TECHNICAL · QUALITY · SECURITY · OTHER`

오류: `400` 필수 필드(title/reason/decisionType/author) 누락·공백·Enum 외 유형, `404` 프로젝트/결정 없음.

## Prompt Engine (TASK-0503)

프롬프트 생성의 단일 엔진입니다. 모든 AI 기능은 `@acos/core`의 PromptTemplate을
등록하고 `PromptEngine.render(key, context)`로만 프롬프트를 만듭니다 —
[docs/architecture/prompt.md](docs/architecture/prompt.md)

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/prompt/templates` | 등록된 템플릿 목록 (현재: `content-generation`, `product-analysis`, `vision-analysis`) |

## LLM Gateway (TASK-0501)

모든 LLM 호출의 단일 진입점입니다. Provider는 `LLM_PROVIDER` 환경변수로 교체
(`mock` 기본 · `openai` · `anthropic` · `gemini` — **3사 전부 공식 연결**),
API 키가 없으면 항상 mock으로 동작합니다 —
[docs/architecture/llm.md](docs/architecture/llm.md)

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/llm` | 선택된 Provider 확인 |
| `GET` | `/llm/health` | **Provider 상태 점검 (TASK-0603)** — 최소 실호출로 키/네트워크/모델 확인 |
| `POST` | `/llm/complete` | `{ messages, model?, maxTokens? }` → 완성 텍스트 + usage (200) |

- 키 설정: `OPENAI_API_KEY` / `ANTHROPIC_API_KEY` / `GEMINI_API_KEY`
  (+ `LLM_*_MODEL`로 모델 덮어쓰기, `LLM_MAX_ATTEMPTS` 재시도)
- **OpenAI Production (TASK-0901)**: feature별 출력 상한
  `LLM_CONTENT_MAX_TOKENS`(4096) · `LLM_ANALYSIS_MAX_TOKENS`(2048) ·
  `LLM_VISION_MAX_TOKENS`(2048), JSON 잘림(finish_reason=length) 방어,
  주입 클라이언트 통합 검증. 실키 스모크 절차:
  [docs/operations/real-provider-smoke.md](docs/operations/real-provider-smoke.md)
- **Cost Governance (TASK-0902)**: `LLM_DAILY_BUDGET_USD`/`LLM_MONTHLY_BUDGET_USD`
  (UTC, 초과 시 429 차단) · 경고 임계 `LLM_BUDGET_ALERT_RATIO`(0.8) ·
  `GET /llm/budget`. **Multi-Provider Foundation**: Provider Registry
  (`GET /llm/providers`) · Model Routing `LLM_MODEL_CONTENT/ANALYSIS/VISION` ·
  웹 **`/providers`** 대시보드
- **Anthropic·Gemini 공식 연결 (TASK-0903)**: Registry 기반 **Provider
  Factory**(`provider.factory.ts` — 새 Provider는 Registry·어댑터·가격표
  3곳만 갱신) · 구조화 출력(Anthropic JSON 지시 강화 · Gemini
  `responseMimeType`) · 3사 통일 잘림 방어 · **Unified Execution**(동일
  스키마·전 Provider 비용 산정) · 웹 `/providers` **Provider 비교**
  (성공률·지연·비용·비용/호출)
- **Cross-Provider Routing (TASK-1001)**: feature별 Provider 매핑
  `LLM_ROUTE_CONTENT`/`LLM_ROUTE_ANALYSIS`/`LLM_ROUTE_VISION`
  (`provider` 또는 `provider:model`) · **호출 시점 해석(재기동 불필요)** ·
  사용 불가 Provider는 기본으로 폴백 · `GET /llm/routing` ·
  Routing Metrics(`/executions/stats`의 `byRoute`) · 웹 **`/routing`** 대시보드
- **Provider Failover (TASK-1002)**: 실행 중 실패 시 우선순위
  `LLM_FAILOVER_PRIORITY`(미설정 = 비활성)에 따라 다음 Provider로 전환 ·
  호출 제한 `LLM_TIMEOUT_MS`(기본 120000) · Provider별 재시도
  `LLM_MAX_ATTEMPTS` 소진 후 전환 · **Health Check 연동**(연속 실패
  `LLM_FAILOVER_HEALTH_THRESHOLD`회 → `LLM_FAILOVER_HEALTH_COOLDOWN_SEC`초 동안
  체인 뒤로) · `GET /llm/failover` 계측 · 웹 `/routing` 하단 표시.
  **예산 초과·요청 검증 오류는 Failover 대상이 아닙니다**(Provider를 바꿔도
  결과가 같음). 이력 Provider 필드(`AnalysisRun.provider` 등)는 실제 호출된
  Provider를 기록합니다
  - **오류 분류 (공식 표준)**: Failover 대상은 Timeout · Provider 5xx ·
    Rate Limit · 일시적 네트워크 오류. 예산 초과 · 검증 오류 · 인증(401/403) ·
    잘못된 API Key · 잘못된 요청은 대상이 아닙니다. `GET /llm/health` 진단
    호출은 운영 계측과 분리됩니다
- **Routing Experiment (TASK-1003)**: feature 트래픽을 여러 변형에 비율로
  분배 — `LLM_EXPERIMENT_CONTENT`/`LLM_EXPERIMENT_ANALYSIS`/
  `LLM_EXPERIMENT_VISION` = `이름|종류|변형=가중치,…`(미설정 = 실험 없음).
  Percentage · **A/B** · **Canary** · Weighted를 하나의 가중 추첨 원리로
  지원하고, 사용 불가 변형은 제외 후 재정규화(전부 불가 시 기존 라우팅) ·
  `GET /llm/experiments` · 변형별 지표(`/executions/stats`의 `byVariant`) ·
  웹 **`/experiments`** 대시보드(설정 비율 ↔ 실제 배정 ↔ 실행 지표 비교)
- **Sticky Assignment & Lifecycle (TASK-1101)**: **Project 기반 고정 배정** —
  같은 프로젝트는 항상 같은 변형(결정적 해시라 재기동·다중 인스턴스와 무관,
  정의가 바뀌면 재배정) · **Start / Stop / Promote / Rollback** 상태 전이
  (`POST /llm/experiments/:feature/:action`, EDITOR 이상, 전이 이력 감사) ·
  STOPPED는 기존 라우팅으로, PROMOTED는 승자 변형으로 전 트래픽 ·
  **Assignment Dashboard**(`GET /llm/experiments/assignments` + 웹
  `/experiments`) — 배정(실험 결과)과 실행(Execution)을 나란히 표시.
  권한은 **Start·Stop = EDITOR 이상 / Promote·Rollback = ADMIN 전용**이며,
  정의 변경으로 재배정이 발생하면 사유와 함께 Audit 이력이 남습니다
- **Experiment Analytics (TASK-1102)**: 변형별 성과 요약(성공률 + **Wilson
  95% 신뢰구간**·지연·비용·호출당 비용) · 기준 변형 대비 **성공률/지연/비용
  비교** · **승자 추천**(성공률 → 비용 → 지연 순, 표본이 모자라면 추천 보류) ·
  **Confidence Score**(양측 2-비율 z검정) · `GET /llm/experiments/:feature/
  analytics` + 웹 `/experiments` Analytics Dashboard.
  승격은 운영자 수동 절차이며 추천은 근거를 제공할 뿐입니다.
  최소 표본은 `LLM_EXPERIMENT_MIN_SAMPLES`(기본 30)로 조정하고, 관측 기간은
  **실험 정의가 바뀔 때만** 초기화합니다(START/STOP은 기간 유지)
- **Provider 관리 콘솔 (TASK-1201)**: Provider Enable/Disable · 모델 · 예산 ·
  실험을 **운영 중에** 조정하는 ADMIN 콘솔(웹 **`/admin/console`**).
  설정 원칙은 그대로 Code-first이고 콘솔은 그 위의 **오버라이드**입니다 —
  `유효값 = 오버라이드 ?? 환경변수 ?? 기본값`이며, 해제하면 환경변수로
  되돌아가고 화면에 각 값의 출처가 표시됩니다. 잘못된 값은 저장 시점에 400으로
  막고(마지막 Provider는 끌 수 없음), 모든 변경은 감사 이력으로 남습니다.
  `GET /admin/console` · `PUT /admin/settings/:key` · `GET /admin/audit`

## 운영 준비 (TASK-1202, Sprint 12)

배포해도 되는지를 **실제 상태로 판정**합니다 — 문서로만 있는 체크리스트는
지켜졌는지 확인할 수 없으므로, 기계가 판정할 수 있는 항목은 전부 자동화하고
사람이 봐야 하는 항목만 "직접 확인"으로 남깁니다.

- **Environment Validation**: 환경변수 선언(`packages/core/src/ops/env-spec.ts`)이
  **단일 원천** — 검증·대시보드·런북이 같은 선언을 씁니다
- **Startup Validation**: 기동 시 환경을 검증하고, **운영에서 오류가 있으면
  기동하지 않습니다**(잘못된 설정으로 뜬 서버가 더 위험). 개발에서는 경고만
- **Deployment Checklist**: 환경·DB·마이그레이션·저장소·관리자·Provider·
  예산·Failover를 자동 판정, 스모크·백업은 직접 확인
- **Health Dashboard**: 웹 **`/admin/health`** — 배포 가능 여부·차단 사유·
  구성 요소·설정 현황(비밀 값은 설정 여부만)
- **Runbook / Recovery Guide**:
  [docs/operations/production-runbook.md](docs/operations/production-runbook.md) ·
  [docs/operations/recovery-guide.md](docs/operations/recovery-guide.md)

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/health` | 생존 확인 — 본문 `OK` (무인증) |
| `GET` | `/health/live` | 구조화된 생존 확인 (무인증, 내부 구성 비노출) |
| `GET` | `/health/ready` | **배포 준비 보고 (ADMIN)** — 체크리스트·구성 요소·설정 현황 |

## 실 Provider 운영 점검 (TASK-1301, Sprint 13)

실 Provider로 **실제 돈이 나가는 운영**을 시작할 때 필요한 확인입니다.
웹 화면은 **`/admin/production`**(ADMIN 전용).

- **API Key Validation**: Provider별 키 형식·조건부 필수 여부·어댑터 생성
  여부. **키 값은 노출하지 않습니다**(앞 6자 힌트와 길이만). `sk-xxxx…`·
  `changeme` 같은 **플레이스홀더를 별도 상태로** 잡습니다 — 형식 검사만으로는
  통과해 버리는 배포 사고의 단골입니다
- **Live Check**: 실제 API를 호출하므로 **기본으로 실행하지 않습니다**.
  버튼(또는 `?live=1`)으로만 실행하고, 실행 여부를 응답에 명시합니다
- **Cost Verification**: 기록된 비용을 가격표로 재계산해 대조. 가격표에 없는
  모델은 비용이 `null`로 남아 **예산 상한이 무력화되므로** 가장 먼저 드러냅니다
- **Production Monitoring**: Provider별 성공률·지연 분포(p50/p95/p99)·비용과
  경보. **표본이 적으면 판정하지 않습니다**(`unknown`) — 1회 실패로 "장애"라고
  말하지 않습니다. Health Check·Live Check 같은 **진단 호출은 관측에서
  제외**되고(제외된 수는 함께 표시), 판정 기준은 `LLM_MONITOR_*`로 조정합니다
- **Vision Production**: 이미지 전달 형식이 Provider마다 다릅니다(OpenAI
  `image_url` / Anthropic `image` block / Gemini `inlineData`). 하나만 맞으면
  Provider가 바뀌는 순간 이미지가 조용히 빠지므로 세 Provider 전부 회귀 테스트
- **Provider Smoke Test**: `scripts/real-provider-smoke.mjs` — 키가 설정된
  **모든** Provider Health Check + Vision 커버리지 + 비용·모니터링 판정

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/llm/providers/validate` | **API Key 검증 (ADMIN)** — `?live=1`이면 실호출(과금) |
| `GET` | `/llm/cost-verification` | **비용 검증 (ADMIN)** — `?hours=`(기본 24) |
| `GET` | `/llm/monitoring` | **운영 모니터링 (ADMIN)** — `?minutes=`(기본 60) |

**운영 필수 키 (CTO 결정 1202-②)**: 설정에서 참조하는 Provider의 API Key는
운영 필수입니다 — 참조하는데 키가 없으면 **서버가 기동하지 않습니다**(Fail
Fast). 쓰지 않는 Provider의 키는 없어도 됩니다.

자세한 내용: [docs/architecture/llm.md](docs/architecture/llm.md)

## 운영 자동화·경보 (TASK-1302, Sprint 13)

TASK-1301의 점검들은 **사람이 화면을 열어야** 결과를 볼 수 있었습니다.
이제 주기적으로 돌고, 문제가 생기면 **사람을 찾아갑니다**.

- **Scheduled Checks**: 비용 검증(15분) · 설정 검증(15분) · 운영 상태(1시간).
  간격은 `OPS_CHECK_*_INTERVAL`(`15m`·`1h`·`30s` 형식)로 조정하고 `off`로
  끕니다. **예약 점검은 Live Check를 하지 않습니다** — 실 키를 자동 호출하면
  과금이 사람 모르게 발생합니다
- **Alerts**: 예산 · Provider 장애 · 미산정 모델 · 설정 오류 4종.
  **같은 문제는 한 번만 알립니다**(`ALERT_COOLDOWN_MS`, 기본 30분) — 같은
  경보가 반복되면 사람이 무시하기 시작하고, 그 순간 경보 체계는 없는 것과
  같아집니다. 심각도가 올라가면 쿨다운과 무관하게 알리고, **해소도 알립니다**
- **전달 채널**: 로그(항상) + 웹훅(`ALERT_WEBHOOK_URL`). 웹훅 실패가 점검을
  실패시키지 않습니다 — 알림이 죽었다고 감지까지 멈추면 상황이 더 나빠집니다
- **CI/CD Deployment Gate**: `scripts/deployment-gate.mjs` — 파이프라인이
  `/health/ready`로 배포 가능 여부를 자동 판정합니다.
  `0` 가능 / `1` 불가 / **`2` 판정 불가**(확인하지 못한 것은 통과가 아닙니다)

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/alerts` | **경보 현황 (ADMIN)** — 활성·최근 경보, 예약 점검 구성 |
| `POST` | `/ops/checks/run` | **점검 수동 실행 (ADMIN)** — `?job=`으로 하나만 |

```bash
# 배포 파이프라인에서
API_BASE=https://api.example.com GATE_EMAIL=... GATE_PASSWORD=... \
  node scripts/deployment-gate.mjs || exit 1
```

## 운영 플랫폼 (TASK-1401, Sprint 14)

TASK-1302가 남긴 두 부채를 갚습니다: **예약 점검의 인스턴스별 중복 실행**과
**알림이 한 번 실패하면 아무도 모르는 채로 끝나던** 문제.

- **Distributed Scheduler / Leader Election / Lock**: 예약 실행은 Redis 잠금을
  잡은 인스턴스만 수행합니다(`REDIS_URL`). 임차는 **반드시 만료**되어(기본 30초)
  리더가 죽어도 다른 인스턴스가 인계받고, **소유자 확인 후에만** 갱신·해제해
  리더가 둘이 되지 않습니다. Redis가 없으면 단일 인스턴스 모드이며 **그 사실을
  화면에 드러냅니다**
- **Notification Center**: Slack · Email · Webhook. 채널마다 최소 심각도와 해소
  알림 여부를 따로 정합니다 — 모든 warning을 밤중에 받으면 사람이 알림을 끕니다.
  **주소는 어떤 응답에도 담지 않습니다**
- **Webhook Retry**: 지수 백오프(최대 4회). **4xx는 재시도하지 않습니다** —
  같은 요청은 같은 답을 받습니다. 모든 시도 결과를 기록해 "왜 아무도 못
  받았는가"를 추적할 수 있습니다
- **Alert History / Archive**: **삭제하지 않습니다**. 해소 후 90일이 지나면
  보관으로 옮기고, 활성 경보는 절대 보관하지 않습니다. 이력 요약은 종류별
  발생 횟수와 **평균 해소 시간**을 냅니다 — 경보가 많은 것보다 오래 방치되는
  것이 더 나쁜 신호입니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/alerts/history` | **경보 이력 (ADMIN)** — 보관 포함·평균 해소 시간 |
| `POST` | `/ops/alerts/archive` | **보관 정리 (ADMIN)** — 삭제가 아닙니다 |
| `GET` | `/ops/notifications` | **전송 시도 이력 (ADMIN)** |
| `POST` | `/ops/notifications/test` | **채널 시험 (ADMIN)** — 실제로 전송합니다 |

**배포 게이트**: 운영에서는 `GATE_STRICT`·`GATE_ALERTS`가 **기본 ON**입니다 —
안전한 쪽이 기본이어야 사람이 잊었을 때 사고가 나지 않습니다.

## 고가용·운영 신뢰성 (TASK-1501, Sprint 15)

- **Scheduler Stopped Alert**: Redis 장애 시 **단일 모드로 자동 폴백하지
  않습니다**(폴백하면 여러 인스턴스가 동시에 점검을 돌립니다). 대신 멈춘 사실을
  critical로 알립니다. 감시자는 **잠금 없이** 돌아야 정작 알려야 할 때 알릴 수
  있고, 간격의 3배를 넘겨야 멈춘 것으로 봅니다
- **Persistent Notification Queue**: 경보를 큐에 담고 Retry Worker가 보냅니다 —
  **재시작을 견딥니다**. 워커는 리더만 돌립니다(같은 알림이 여러 번 가지 않도록)
- **Dead Letter Queue**: 4xx이거나 최대 시도를 소진하면 `DEAD`로 남기고
  **지우지 않습니다**. 설정을 고친 뒤 `requeue`로 다시 보냅니다
- **Alert Archive 예약화**: 네 번째 예약 점검으로 편입되어 **매일 04:00**(운영
  서버 로컬 시각, `TZ`)에 돕니다. 그 시각 전에는 한 번도 안 돌았어도 돌지 않습니다
- **운영 기본 채널 정책**: Slack Warning 이상 / **Email Critical 이상** /
  Webhook Warning 이상 / 해소 포함 — 메일은 쌓이면 읽지 않게 되기 때문입니다.
  환경변수로 전부 변경 가능합니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/notifications/queue` | **큐 현황 (ADMIN)** — 대기·성공·Dead Letter |
| `POST` | `/ops/notifications/queue/drain` | **지금 보내기 (ADMIN)** |
| `POST` | `/ops/notifications/queue/requeue` | **Dead Letter 재시도 (ADMIN)** |

## 운영 검증·재해 복구 (TASK-1601, Sprint 16)

"잘 돌고 있는가"(`/admin/production`)와 별개로, **"지금 무너지면 되살릴 수
있는가"** 를 판정하는 화면입니다 — 웹 **`/admin/operations`**(ADMIN 전용).
절차는 [docs/operations/disaster-recovery.md](docs/operations/disaster-recovery.md).

- **Real SMTP Validation**: 실제 SMTP에 연결·인증까지 확인합니다.
  **메일은 보내지 않습니다** — 점검이 수신함을 채우면 사람이 무시하게 됩니다.
  미설정은 실패가 아니라 **미구성**으로 알립니다
- **Backup Automation**: `pg_dump --format=custom`을 매일 **03:00**(로컬)에
  받고 **크기를 기록**합니다 — 1KB 미만은 빈 덤프로 보고 실패로 셉니다.
  보존 기간이 지나도 **최근 3개는 남깁니다**
- **Restore Verification**: 매일 **03:30**(로컬)에 최신 덤프를 **별도
  DB**(`BACKUP_RESTORE_DB_URL`)에 복원하고 테이블 수를 셉니다. 운영 DB에는 절대
  복원하지 않습니다. **복원해 보지 않은 백업은 백업이 아닙니다** — 이력이 없으면
  `missing`이고, 그것은 통과가 아닙니다
- **Disaster Recovery Checklist**: 백업·복원·DB·저장소가 복구를 좌우하는
  항목이고, Redis·경보 채널은 아닙니다. 복구 절차 숙지·연락 체계는 자동 판정이
  불가능하므로 **`직접 확인`으로 남깁니다**
- **Provider Smoke Automation**: 예약 자리는 있지만 **기본은 꺼져 있습니다** —
  실제 과금되기 때문입니다. "지금 점검"도 **꺼진 작업은 건너뜁니다**
- **Redis Health**: Redis가 죽어도 **LLM 호출은 계속됩니다**. 예약 점검만
  멈추고, 30분 이상 지속되면 Critical 경보가 반복됩니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/readiness` | **운영 대시보드 (ADMIN)** |
| `POST` | `/ops/backup/run` | **지금 백업 (ADMIN)** |
| `POST` | `/ops/backup/verify-restore` | **지금 복원 검증 (ADMIN)** |
| `POST` | `/ops/notifications/verify-smtp` | **메일 경로 확인 (ADMIN)** |

## Reliability Expansion (TASK-4701, Sprint 47)

TASK-4603의 작업 층을 **나머지 AI 경로로 넓히고**, 토큰·비용을 잇고, 죽은
프로세스가 남긴 작업을 되살리고, 라이브 검사 일부를 CI로 옮겼습니다.
자세히: `docs/operations/reliability-expansion.md`

- **작업 종류 1 → 4**: 묶음 OCR에 더해 **분석**(멀티모달이라 가장 비쌉니다) ·
  **생성**(프롬프트도 출력도 가장 깁니다) · **발행**(과금은 없지만 되돌리기가
  가장 번거롭습니다). 기존 서비스는 **부르기만** 하므로
  `POST /images/:id/ocr` · `POST /products/:id/analysis` ·
  `POST …/contents/generate` · `PATCH …/contents/:id/status`는 예전 그대로입니다
- **건너뛸 문제와 멈춰야 할 문제를 한자리에서 가릅니다**(`judgeBatchItem`):
  4603의 라이브 결함 4건 중 2건이 이 규칙이었고, 같은 모양의 작업이 넷이
  되었기 때문입니다. **자격 증명 실패는 한 건의 문제가 될 수 없으므로**
  묶음을 멈춥니다 — 키가 만료된 날 전부 건너뛰고 성공으로 끝나면 안 됩니다
- **토큰의 뜻을 우리 말로 옮깁니다**: Anthropic은 입력에서 캐시를 **빼고**
  오고, OpenAI는 **포함**해서 오고(캐시는 싸다), Gemini는 생각 토큰이 출력에
  **없습니다**(청구는 된다). 셋이 서로 다른 방향으로 틀려서 **합계는 어느
  쪽으로도 못 믿었습니다.** 캐시 읽기는 1/10, 쓰기는 1.25배로 셉니다 —
  캐시는 공짜로 생기지 않습니다
- **상세가 없으면 예전 셈과 한 푼도 다르지 않습니다**: 새 셈을 과거에
  소급하면 지금까지의 모든 기록이 "불일치"로 뜨고 진짜 불일치가 묻힙니다
- **작업이 자기 비용을 압니다**: 토큰은 원래 있었고 없던 것은 **작업과 호출을
  잇는 선**이었습니다. 새로 재지 않고 요청 id로 읽어 옵니다 — 두 번 재면
  같은 사실에 두 개의 답이 생깁니다. 못 재면 **0이 아니라 `null`**입니다
- **자동 이어하기**(`JOB_AUTO_RESUME=on`, 기본 **꺼짐**): 30초 심장박동,
  90초 침묵이면 `interrupted`(**실패가 아니라 "끝났는지 모른다"**).
  `job_runs` 자체가 큐입니다 — 큐를 따로 두면 같은 사실이 두 군데 살고
  언젠가 어긋납니다. 자동은 수동(3회)보다 적은 **2회**, 한 번에 **5건**까지,
  상한에 닿아도 **행을 지우지 않습니다**
- **라이브 검사 15건 중 11건을 CI에서** 돌립니다(`pnpm check:live-coverage`).
  무엇이 CI에서 되는지는 문서의 문장이 아니라 판정입니다.
  **CI가 초록이라고 라이브 검증이 끝난 것이 아닙니다** — 거기서 증명하는
  것은 배선이 맞는가입니다
- **가격표에 나이와 출처**(180일) · **미산정을 이름으로**
  (`GET /llm/pricing-health`): 지금까지는 "비용이 빠진 호출 12건"이었고 그
  문장으로 사람이 할 수 있는 일이 없었습니다. **없는 단가를 채우지
  않았습니다** — 근거 없는 숫자로 낸 비용은 없는 것보다 나쁩니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/jobs/analysis-batch` | 묶음 분석 — **실 호출·과금** |
| `POST` | `/jobs/content-batch` | 묶음 생성 — **실 호출·과금** |
| `POST` | `/jobs/publish-batch` | 묶음 발행 — 거버넌스는 그대로 거칩니다 |
| `GET` | `/jobs/queue/status` | 자동 이어하기 상태 — **조회는 아무것도 이어하지 않음** |
| `POST` | `/jobs/queue/sweep` | 지금 한 번 훑기 — 사람이 누를 때만 |
| `GET` | `/llm/pricing-health` | 단가의 나이 · 가격표에 없는 모델 |

## Job Reliability (TASK-4603, Sprint 46)

예외 처리 · 로그 · 자동 복구 · 성능 계측을 **한자리에** 모은 층입니다.
호출 지점마다 손으로 붙이면 **붙이는 것을 잊은 경로**가 생기고, 그 경로는
사고가 난 날에만 드러납니다.

**기존 기능은 하나도 바뀌지 않았습니다** — 변경된 기존 파일 7개가 전부
추가만(+309 / −0)이고 나머지는 신규입니다.

- **실패 분류**(`classifyFailure`): "다시 해 볼 만한 실패인가, 사람이 고쳐야
  하는 실패인가". `unknown`은 재시도하지 않습니다 — 모르는 실패를 반복하면
  어떤 실패인지 영영 모른 채로 돈만 씁니다. **우리가 막은 것(예산·게이트)은
  상태 코드보다 먼저 봅니다**: 예산 초과는 HTTP 429로 나가는데, 상태 코드만
  보면 "잠시 후 다시 시도"가 되고 예산은 기다린다고 열리지 않습니다
- **사용자 문장과 운영자 문장을 가릅니다**: 원문에 무엇이 들어 있는지 미리
  알 수 없으므로 사용자에게는 "무엇을 하면 되는가"만 보여 주고, 원문은
  로그로만 갑니다
- **로그**(`LOG_LEVEL` · `job_events`): 등급은 넷뿐이고 한 줄의 맨 앞이 작업
  id입니다. **비밀은 적기 전에 이름으로 가립니다** — 로그는 가장 많이
  복사되는 텍스트입니다
- **체크포인트와 이어하기**(`POST /jobs/:id/resume`): 끝난 단계를 다시 사지
  않습니다. 다만 "이어한다"는 **하지 않은 일을 했다고 치는 것**과 종이 한 장
  차이라, 끝난 단계만·순서대로만 건너뛰고 입력이 달라지면 처음부터 합니다
- **작업 재시도**: 알림의 4회보다 적은 **3회**입니다 — 알림을 네 번 보내는
  것과 LLM을 네 번 부르는 것은 비용이 다릅니다
- **성능 계측**: 단계별 시간·토큰·전체 시간. **토큰을 모르면 0으로 채우지
  않고**, **안 잰 시간을 감추지 않으며**, **메모리를 이 작업의 것이라고 말하지
  않습니다**(프로세스 전체 값이므로 이름이 `processHeapDeltaBytes`입니다)
- **전역 예외 필터**: `HttpException`은 **그대로 통과합니다.** 달라지는 것은
  분류되지 않은 오류 하나뿐이고, 그때 원문 대신 할 수 있는 일과 `requestId`를
  돌려줍니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/jobs/ocr-batch` | 묶음 OCR — **실 호출·과금**, 중간에 죽어도 이어할 수 있음 |
| `POST` | `/jobs/:id/resume` | 이어하기 — 끝난 단계는 다시 사지 않음 |
| `GET` | `/jobs/:id` | 작업 · 계측 · 로그 |
| `GET` | `/jobs/metrics/stages` | 단계별 추세 — 표본이 적으면 판정 유보 |

## Operations Intelligence (TASK-4601, Sprint 46)

CTO 정책 4601-①~⑤ 반영 — 주제는 **"닿는다고 믿는 것"과 "지금 닿는 것"을
가르고, 흩어진 판정을 한 화면으로 모은다**입니다.

- **Teams Adaptive Card 전환 계획**(정책 4601-③ · `TEAMS_CARD_FORMAT` ·
  `docs/operations/teams-adaptive-card-plan.md`): 두 형식을 **모두**
  만들었지만 **기본값은 아직 MessageCard**입니다. 이 저장소는 실제 Teams
  워크스페이스에 붙어 본 적이 없고, 확인할 수 없는 형식을 기본값으로 두면
  그것이 틀렸다는 사실을 **첫 장애 때** 알게 됩니다. 특히 **봉투 없이 카드만
  보내면 Teams는 200을 돌려주고 아무것도 안 띄웁니다** — 우리 기록에는
  `ok: true`로 남는 **성공으로 기록되는 실패**입니다. 바꾸는 것도 되돌리는
  것도 한 줄입니다
- **최근 24시간 도달**(정책 4601-④ · `GET /ops/notifications/health`):
  "한 번이라도 닿았는가"는 너무 약한 질문이었습니다 — 3주 전에 한 번 닿은
  채널과 지금 닿는 채널이 같은 초록으로 보입니다. 다만 **조용한 것과 죽은
  것은 다릅니다**: 24시간 동안 시도가 없었다면 장애가 없었기 때문일 수
  있고, 좋은 하루를 실패로 칠하면 그 경고가 배경 소음이 됩니다. 그 상태는
  실패도 통과도 아닌 **`silent`(모른다)** 이며, 확인하는 방법을 함께 적습니다
- **담당자 직접 알림**(정책 4601-④ · `ALERT_OWNER_CONTACTS`): 채널을 보는
  사람과 항목을 맡은 사람은 대개 다릅니다. **연락처를 못 찾아도 조용히
  삼키지 않고** 공용 채널로 보내며 그 사실을 본문에 붙입니다. 이름에서
  주소를 **유추하지 않고**, 직접 보내도 **공용 채널을 끄지 않습니다**
- **재전송**(정책 4601-④ · `POST /ops/notifications/resend`): 재시도는 한
  번의 전송 안에서 끝나므로, 슬랙이 5분 죽어 있었다면 그 사이의 경보는
  **영영 전달되지 않았습니다.** 15분→1시간→4시간 3회로 **같은 `alertKey`로**
  다시 보내되, 4xx는 보내지 않고, 해소된 것도 보내지 않으며, **상한에 닿아도
  조용히 그만두지 않습니다**(포기한 것도 목록에 남습니다)
- **통합 운영 대시보드**(정책 4601-⑤ · `/admin/overview` ·
  `GET /ops/overview`): Validation · Attribution · Notification · Recovery를
  한 화면에. **여기서 새로 판정하지 않습니다.** 통합 화면의 유혹은 "전체
  정상"이라는 한 줄인데, 못 본 갈래가 있으면 그 한 줄이 거짓말이 되므로
  **못 본 사실을 문장 맨 앞에** 적습니다. 그리고 **못 읽은 것과 판정을
  유보한 것을 가릅니다** — 둘 다 통과가 아니지만 할 일이 다릅니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/overview` | **통합 운영 상태** — 인용만, 새로 판정하지 않음 |
| `GET` | `/ops/notifications/health` | 채널 도달 — **최근 24시간 기준** |
| `GET` | `/ops/notifications/resend` | 재전송 계획 — **조회는 보내지 않음** |
| `POST` | `/ops/notifications/resend` | 재전송 실행 — 같은 키로, 몇 번째인지 적어서 |

## Go-Live Platform (TASK-4501, Sprint 45)

CTO 정책 4501-①~⑤ 반영 — 주제는 **볼 수 있는 범위를 넓히고, 마지막 관문을
숫자가 아니라 사실로 지킨다**입니다.

- **IPv6 Trusted Proxy**(정책 4501-① · `TRUSTED_PROXY_IPS`): TASK-4401의
  파서는 IPv4만 읽었고 IPv6 선언은 **통째로 버렸습니다** — 그 상태는 IPv6로
  들어오는 프록시 뒤에서 이 보호가 꺼진 것과 같습니다. 이제 128비트로
  비교하며, **표기가 달라도 같은 주소로 보고**(`::1` · `0:0:0:0:0:0:0:1` ·
  `[::1]`), **`::ffff:10.0.0.5`는 IPv4로 되돌리며**, **다른 체계끼리는
  비교하지 않습니다**(우연히 맞아떨어지면 그건 신뢰가 아니라 사고입니다).
  `::/0`도 경계를 없앤 선언이므로 맞지 않는 것으로 봅니다
- **업로드 단계 projectId 전달**(정책 4501-② · `POST /uploads/images?projectId=`):
  업로드 직후의 이미지는 아직 상품에 붙어 있지 않아 프로젝트에 닿을 길이
  없었고, 그 상태로 돌린 OCR 비용은 **영영 귀속되지 않았습니다**(기록은
  실행 시점의 사실이라 나중에 상품을 붙여도 소급되지 않습니다). 이제
  소속을 업로드에서 받습니다 — **없는 프로젝트 id는 조용히 버리지 않고
  400으로 거절하고**(버리면 사용자는 밝혔다고 믿는데 기록은 미귀속입니다),
  상품 연결과 업로드 선언이 다르면 **구조를 쓰되 달랐다는 사실을 남깁니다**
- **Notification Adapter 확장**(정책 4501-③ · `ALERT_TEAMS_WEBHOOK_URL`):
  Slack · Email · Webhook에 **Teams**가 늘었습니다. 채널마다 담기는
  **모양**은 다르지만 담기는 **사실**은 같습니다 — 채널에 따라 다른 사실이
  나가면 같은 장애에 두 개의 답이 생깁니다. 심각도는 **색과 글자 둘 다로**
  남기고, 주소가 없으면 버튼을 만들지 않습니다
- **실 Validation 실행기**(정책 4501-④ · `POST /ops/validation-run/execute`):
  지금까지는 순서만 돌려줬습니다. 이제 실제로 밟습니다 — **잠금은 그대로**
  이고(준비 전에는 403), 되돌릴 수 없는 것은 뒤에 있으며, **스텁 응답이
  하나라도 있으면 성공이 아닙니다.** 실패도 `validation_runs`에 남습니다
- **최종 Go-Live 체크리스트**(정책 4501-⑤ · `/admin/go-live` ·
  `GET /ops/go-live`): 마지막 질문 하나에 답합니다 — **이제 운영이라고
  말해도 되는가.** 여덟 조건을 **인용만** 합니다. **검증이 성공하지 않으면
  나머지를 세지 않습니다** — 그 상태는 준비가 끝난 것이 아니라 아직 시작도
  안 한 것이고, "7/8 완료"라고 적으면 빠진 하나가 전부인 상황에서 숫자가
  진행을 흉내 냅니다. 읽지 못한 항목은 `unmet`과 같은 무게로 막고,
  **선언은 사람이 합니다**

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/go-live` | **최종 Go-Live 체크리스트** — 인용만, 새로 판정하지 않음 |
| `POST` | `/ops/validation-run/execute` | **실 Validation 수행** — 실 호출·과금, 준비 전에는 403 |
| `POST` | `/uploads/images?projectId=` | 업로드 단계 귀속 — 없는 프로젝트는 400 |

## Production Activation Platform (TASK-4401, Sprint 44)

CTO 정책 4401-①~⑥ 반영 — 주제는 **볼 수 없던 것을 신뢰 경계 안에서 보고,
남은 일을 순서와 되돌리는 법까지 적는다**입니다.

- **Trusted Proxy 기반 Host Discovery**(정책 4401-① · `TRUSTED_PROXY_IPS`):
  프록시가 Host를 바꿔 전달하는 구성에서는 우리가 보는 `Host`가 내부
  주소이고, 사용자가 친 도메인은 `X-Forwarded-Host`에 있습니다. 그 헤더를
  **구분할 수 있을 때만** 봅니다 — 우리에게 직접 연결한 상대가 선언된
  프록시일 때만. **선언이 없으면 보지 않고**, 신뢰하지 않는 상대가 보낸
  헤더는 **버리되 세며**, 값이 여러 개면 **추측하지 않습니다**
- **미귀속 실행 경로 분석**(정책 4401-② · `GET /ops/cost/attribution` ·
  목표 95%): 귀속률만 보면 "덜 됐다"까지만 알 수 있습니다 — 이제 **어느
  경로가 빠뜨리는지** 이름으로 말합니다. **표본이 적으면 달성이라고 하지
  않고** 달성도 미달도 아닌 판정 보류로 둡니다. 정렬은 비율이 아니라
  **건수**입니다(비율로 세우면 고쳐야 할 순서가 뒤집힙니다)
- **무시 검토 알림과 에스컬레이션**(정책 4401-③ ·
  `GET /ops/neglect/notices`): 검토일 3일 전 · 당일 · 2주 뒤의 3단계로
  **담당자에게** 갑니다. **에스컬레이션은 등급을 올리는 것이 아니라 받는
  사람을 넓히는 것**입니다 — 오래된 소식이 지금 터진 장애와 같은 소리로
  울리면 진짜 장애가 묻힙니다. **알림은 무시의 상태를 바꾸지 않습니다**
- **검증 환경 최종 준비**(정책 4401-④ · `config/validation.env.example`):
  채워야 하는 칸의 이름과 이유만 적고 **비밀은 하나도 없습니다**
- **운영 활성화 런북**(정책 4401-⑤ · `/admin/runbook` ·
  `docs/operations/production-activation-runbook.md`): 시작한 다음 무엇을
  어떤 순서로 하고 **잘못되면 어떻게 되돌리는지** 적습니다. 되돌릴 수 없는
  단계는 그렇게 적혀 있고, 되돌릴 수 없는 것은 뒤에 있습니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/runbook` | **운영 활성화 런북** — 단계별 되돌리는 법 포함 |
| `GET` | `/ops/cost/attribution` | 미귀속 실행 경로 — 표본이 적으면 판정 보류 |
| `GET` | `/ops/neglect/notices` | 검토 알림 계획 — **조회는 보내지 않음** |

## Production Readiness Platform (TASK-4301, Sprint 43)

CTO 정책 4301-①~⑥ 반영 — 주제는 **보호가 볼 수 없던 것을 보게 하고, 그
사실을 숨길 수 없게 만든다**입니다.

- **운영 트래픽 기반 Host Discovery**(정책 4301-① · `GET /ops/hosts`의
  `discovery`): 설정값만 보면 **리버스 프록시 뒤의 별칭 도메인**이 보이지
  않습니다 — 사용자는 그 주소로 들어오는데 우리 설정 어디에도 그 이름이
  없고, 검증 대상 보호는 그것을 모르는 주소로 통과시킵니다. 이제 실제
  요청의 `Host`를 관측합니다. 다만 **자동으로 목록에 넣지 않습니다**:
  `Host` 헤더는 **요청하는 쪽이 적는 값**이라 자동 등록은 바깥에서 우리
  보호 목록에 글을 쓰게 하는 것입니다. 서로 다른 호스트는 50개까지만
  담고 **넘치면 넘쳤다고 말합니다** — 그 상태에서 "목록에 없는 호스트
  0개"는 사실이 아니라 우리가 더 안 본 것이므로 준비 단계도 `unknown`이
  됩니다
- **실행 경로 전체 projectId 귀속**(정책 4301-②): 이 값은 이미 호출
  지점까지 와 있었는데 **기록에는 안 남고 있었습니다.** OCR은
  이미지→상품→프로젝트 **조인**으로 채우고(짐작이 아니라 기록에 이미 있던
  사실), 그런 연결이 없는 옛 실행 기록은 **채우지 않습니다.** 그리고
  **주인을 못 찾은 것과 주인이 없는 것을 가릅니다** — 개발용 호출은
  귀속률 분모에서 빼되 합계에는 남깁니다(닿을 수 없는 100%를 요구하는
  지표는 곧 아무도 안 봅니다). 전체 창과 최근 창의 귀속률을 **함께**
  냅니다: 전체만 보면 고친 것이 안 보이고, 최근만 보면 청구서가 틀렸다는
  사실이 가려집니다
- **방치 항목의 무시·담당자·검토일**(정책 4301-③ ·
  `POST /ops/neglect/:checkId/ignore`): 지금 고칠 수 없는 항목이 매일
  경보하면 그 채널 전체가 무시됩니다. 그래서 무시를 두되, **무시는
  해결이 아니라는 사실을 구조로 강제합니다** — 목록에서 사라지지 않고,
  연속 기간 시계는 계속 가고, 검토일이 반드시 있고(최대 90일), 검토일이
  지나면 자동으로 풀리며 **경보가 되돌아오고**, 담당자 이름이 필요합니다.
  요약은 "방치 3건 · 무시 중 2건"으로 적고 **빼서 말하지 않습니다**
- **Production Readiness Dashboard**(정책 4301-④ · `/admin/readiness` ·
  `GET /ops/readiness-board`): 여섯 판정을 한 화면에 모읍니다. **여기서
  새로 판정하지 않습니다** — 각 칸은 어느 판정에서 왔는지를 달고 다니고
  진행률도 준비 단계 판정의 분모를 그대로 씁니다. 자기 점수를 계산하면
  같은 사실에 두 개의 답이 생기고, 어긋나는 순간 둘 다 못 믿게 됩니다
- **검증 환경 최종 준비**(정책 4301-⑤⑥ · `pnpm validation:preflight` ·
  `docs/operations/validation-environment.md`): 막고 있는 것을 명령 하나로
  출력하며 **강제로 통과시키는 옵션은 없습니다.** 기준선 단계는 스냅샷
  2점이어도 **20시간 이상 떨어져 있어야** 통과합니다 — 몇 분 간격으로 두
  점을 찍어 통과시키면 그건 기준선이 아니라 초록을 산 것입니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/readiness-board` | **운영 준비 화면** — 다른 판정을 인용만 함 |
| `POST` | `/ops/neglect/:checkId/ignore` | 방치 무시 — 사유·담당자·검토일 필수 |
| `POST` | `/ops/neglect/ignores/:id/revoke` | 무시 취소 — 결정 기록은 남음 |
| `GET` | `/ops/neglect/ignores` | 무시 이력 (취소된 것 포함) |

## Enterprise Cost & Neglect Intelligence (TASK-4201, Sprint 42)

CTO 정책 4201-①~⑥ 반영 — 주제는 **보호와 지표가 스스로 낡는 것을
막는다**입니다.

- **운영 호스트 자동 검증**(정책 4201-① · `GET /ops/hosts`): 검증 대상
  보호는 `PRODUCTION_HOSTS`와 대조해 동작하는데 그 목록은 **사람이 손으로
  적습니다.** 도메인이 바뀌면 목록은 그대로 남고, **빠진 호스트는 아무
  신호도 내지 않습니다** — 보호가 지켜 주는 것이 아니라 통과시키고 있을
  뿐입니다. 그래서 관측과 대조해 묻되 **자동으로 채우지 않습니다**:
  자동 등록은 보호를 스스로 무력하게 만들고, 스테이징까지 운영으로 올려
  정작 검증 대상을 막습니다. 사설망·로컬 주소는 **묻지도 않습니다**
- **연속 실패와 방치**(정책 4201-② · `GET /ops/neglect`): "3주째 같은
  실패"가 `persisting` 한 단어로만 보이면, 어제 시작된 실패와 석 달 된
  실패가 똑같아집니다. **실패 수는 몇 개인지 말하고 방치는 얼마나 오래
  두었는지 말합니다** — 실패 1건을 석 달 둔 팀이 실패 3건을 어제 만든
  팀보다 나쁩니다. 창의 처음부터 나빴으면 **최소값**이라고 적고, 관측
  공백도 함께 말합니다
- **진단 이력 보존**(정책 4201-③ · `retention.diagnostics.days`, 기본
  90일 · 바닥 14일): 이틀로 줄이면 **모든 연속 실패가 "2일째"** 로 보이고
  석 달 방치된 항목이 어제 시작된 것과 똑같아집니다 — 그건 보존 설정이
  아니라 방치 지표를 끄는 것입니다
- **프로젝트별 운영 비용**(정책 4201-④ · `GET /ops/cost/projects`):
  **귀속되지 않은 금액을 프로젝트에 나눠 얹지 않습니다.** 나누면 합계가
  맞고 표가 깔끔해지지만, 배분할 수 없는 것을 배분하면 그 숫자는 관측이
  아니라 **만들어낸 것**이고 그걸로 팀에 비용을 청구하게 됩니다. 비율의
  분모도 미배분을 포함한 전체입니다. **미산정**(금액을 모른다)과
  **미배분**(주인을 모른다)은 다른 칸입니다
- **검증 준비 확장**(정책 4201-⑤⑥): 보호가 대조할 것이 정확해야 준비가
  끝난 것입니다. 목록이 비어 있으면 준비도 끝나지 않았고, 실행
  잠금(4101-⑥)은 그대로 유지됩니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/hosts` | **운영 호스트 목록 검증** — 자동으로 채우지 않음 |
| `GET` | `/ops/neglect` | 연속 실패 기간과 방치 지표 |
| `GET` | `/ops/cost/projects` | **프로젝트별 비용** — 미배분을 나누지 않음 |

## Enterprise Validation Governance (TASK-4101, Sprint 41)

CTO 정책 4101-①~⑥ 반영 — 주제는 **검증을 시작하기 전에 스스로를
막는다**입니다. TASK-4001이 준비 상태를 판정했다면, 이번에는 **그 판정이
틀렸을 때 일어날 일**을 막습니다.

- **검증 대상 보호**(정책 4101-① · `VALIDATION_TARGET_URL` ·
  `VALIDATION_TARGET_ACK` · `PRODUCTION_HOSTS`): 이 주소는 **실 자격
  증명으로 과금되는 호출을 돌릴 곳**입니다. 잘못 적으면 설정 실수가 아니라
  사고입니다 — 운영을 적으면 검증이 **운영 데이터에 장애를 만들려고**
  하고, 자기 자신을 적으면 **검증하다 죽었을 때 보고할 주체도 함께**
  죽고, 노트북을 적으면 운영 키가 개발 기기에서 나갑니다. 셋 다 한 글자
  차이로 일어납니다. 그래서 주소를 검사하고 **따로 확인을 받습니다** —
  주소를 적는 것과 그곳에 돈이 나가는 호출을 돌려도 된다고 말하는 것은
  다른 행동입니다
- **진단 이력과 비교**(정책 4101-② · `GET /ops/diagnostics/history`):
  "실패 2건"이 **오늘 새로 생긴 것**인지 **계속 그랬던 것**인지는 완전히
  다른 소식입니다 — 새로 생긴 것은 어제 무언가를 바꿨다는 뜻이고 지금
  되돌릴 수 있습니다. 그리고 **사라진 항목을 복구로 세지 않습니다**:
  순진하게 비교하면 없어진 검사가 성과로 보고됩니다
- **배포 단계별 진단**(정책 4101-③ · `DEPLOY_TIER`): 스테이징의 빨간불이
  아무 데도 안 가면 스테이징은 검증 환경이 아니라 **또 하나의 개발
  환경**입니다. 이제 스테이징도 경보하되 **등급은 `warning`까지**입니다 —
  검증 기간에는 여기서 실패를 일부러 만들기까지 하고, 그것이 `critical`로
  울리면 진짜 운영 장애가 묻힙니다. 선언(`DEPLOY_TIER`)과
  구성(`NODE_ENV`)이 어긋나면 실패로 잡습니다
- **만료 초안 되살림**(정책 4101-④ · `POST /ops/incidents/:id/revive`):
  `confirm` | `dismiss` | `reopen`, 셋 다 **사유 필수**. 되살리면서 만료
  표시를 지우면 이력이 "확인된 장애 1건"이 되고, 나중에 읽는 사람은
  **"우리 팀은 초안을 잘 처리한다"** 고 읽습니다 — 실제로는 3주 늦게 본
  것인데도. `expiredAt`은 그대로 두고 **얼마나 늦었는지**를 함께 적습니다
- **검증 실행 순서와 잠금**(정책 4101-⑤⑥ · `GET`/`POST
  /ops/validation-run`): 준비되지 않았으면 **403으로 거절합니다.** 문서로만
  적으면 규칙이 되고, 사람의 기억에 기대는 규칙은 반드시 다시 어긋납니다 —
  "일단 돌려 보자"로 남은 **스텁 상대 성공 기록이 나중에 실연결의 증거로**
  읽힙니다. **강제로 여는 방법은 없습니다**: 막는 조건을 없애는 것이 유일한
  길입니다. 순서는 **되돌릴 수 없는 것을 뒤에** 둡니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/validation-run` | **검증 실행 잠금** — 막힌 이유와 실행 순서 |
| `POST` | `/ops/validation-run` | 검증 시작 — 준비 안 됐으면 **403** |
| `GET` | `/ops/diagnostics/history` | 진단 이력 (`?tier=`) |
| `POST` | `/ops/incidents/:id/revive` | 만료 초안 되살림 — **사유 필수** |
| `GET` | `/ops/incidents/revivals` | 되살림 이력 — 늦게 본 것을 성과로 적지 않음 |

> **정책 4101-⑥의 실제 검증은 여전히 시작할 수 없습니다.** 준비 10단계 중
> 사람이 줘야 하는 3건이 남아 있습니다 — 다만 이제 그 사실이 **코드로
> 막힙니다**: `POST /ops/validation-run`이 403과 함께 막힌 이유를 그대로
> 돌려줍니다.

## Enterprise Operations Intelligence (TASK-4001, Sprint 40)

CTO 정책 4001-①~⑥ 반영 — 주제는 **시간축에서도 스스로를 속이지
않는다**입니다. 지금까지의 판정은 전부 "지금 어떤가"였습니다. 이번에 더한
것은 "나아지는 중인가", "아무도 안 본 채 얼마나 지났는가", "아무도 안
부르면 언제 도는가"입니다.

- **장애 초안 수명**(정책 4001-① · `incident.draft.staleAfterDays` ·
  `incident.draft.expireAfterDays`): 초안은 질문인데, 질문을 만들어 놓기만
  하면 **대답 없는 질문이 쌓입니다.** 그렇다고 **자동으로 기각하지
  않습니다** — 기각은 "아무것도 아니었다"는 판단이고, 아무도 보지 않은 것을
  시스템이 그렇게 판단하면 진짜 장애가 조용히 사라집니다. 대신 3일이면
  경보(초안이 몇 건이든 **경보는 1건**입니다 — 초안마다 내면 막으려던
  뒤덮임이 경보에서 다시 일어납니다), 30일이면 **만료**로 표시합니다.
  **만료는 기각이 아닙니다**: 기각은 "아무것도 아니었다", 만료는 **"아무도
  판단하지 않았다"** 입니다. 그래서 상태는 `DRAFT`로 두고 `expiredAt`만
  적습니다 — 같은 칸에 넣으면 나중에 **방치가 기각 실적으로** 읽힙니다
- **KPI 추세**(정책 4001-② · `GET /ops/kpi/trend`): "MTTR 180분"은 그 자체로
  아무 행동도 만들지 않습니다. 알아야 하는 것은 "나아지는 중인가"이고 그건
  두 번 재야 압니다. 추세가 거짓말하는 세 방식을 막습니다 — **한 점으로 선을
  긋지 않고**("0% 변화"는 안정을 뜻하는데 실제로는 아무것도 모르는
  상태입니다), **기준이 바뀐 구간의 색 변화를 상태 변화로 읽지 않으며**(그때
  쓰인 임계값을 스냅샷에 함께 적습니다), **방향을 봅니다**(MTTR이 느는 것과
  통과율이 느는 것은 반대 소식입니다). 스냅샷은 **하루 한 번** — 화면을 열
  때마다 찍으면 많이 본 날로 표본이 기웁니다
- **임계값 설정 UI·변경 이력**(정책 4001-③ · `GET /ops/kpi/history`): 기준이
  움직인 사실이 화면 밖에 있으면 다음에 이 화면을 보는 사람은 **상태가
  좋아진 줄 압니다.** 각 변경에 느슨해졌는지를 붙이되, 판정할 수 없으면
  `null`로 두고 `false`로 바꾸지 않습니다
- **긴급 채널 미구성을 진단 대상으로**(정책 4001-④): 3901에서 미구성이면
  일반 채널로 되돌리게 했습니다. 되돌리는 것은 옳지만 **되돌린 채로 잊히는
  것**이 문제입니다 — 폴백은 임시 조치이고, 임시 조치는 아무도 보지 않으면
  영구가 됩니다. **개발에서는 경고하지 않습니다**(그 경고가 배경 소음이 되면
  정작 운영의 경고도 안 읽힙니다)
- **기동·일일 진단**(정책 4001-⑤ · `OPS_CHECK_DIAGNOSTICS_AT`, 기본 07:00):
  판정은 많은데 전부 **누군가 부를 때만** 돌았고, 그래서 배포 직후와 매일
  아침이라는 두 순간이 비어 있었습니다. **기동을 막지 않습니다** — 알림
  채널이 미설정이라고 API가 안 뜨면 그게 더 큰 사고입니다. 다만 조용하지도
  않습니다. 그리고 **기동 직후의 "정상"은 아직 아무것도 안 해 본 정상**이라
  그렇게 적습니다
- **검증 스프린트 준비**(정책 4001-⑥ · `GET /ops/validation-plan` ·
  `VALIDATION_TARGET_URL`): **"준비 완료"를 스스로 선언하지 않습니다.** 남은
  것은 자격 증명·나가는 길·검증용 환경이고 셋 다 사람이 주는 것이라,
  자동으로 초록을 칠하면 그 초록은 우리가 한 일이 아니라 **우리가 못 하는
  일을 가린 것**이 됩니다. 대신 10단계마다 **누가 하는가**(코드로 끝낼 수
  있는가, 사람이 줘야 하는가)·**무엇이 증거인가**·**못 하는가 안
  하는가**(앞 단계에 막힌 것을 "우리 쪽에 남은 일"로 세지 않습니다)를
  밝힙니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/kpi/trend` | **KPI 추세** — 한 점으로는 추세를 내지 않음 |
| `GET` | `/ops/kpi/history` | 임계값 변경 이력 — 느슨해진 변경 표시 |
| `POST` | `/ops/kpi/snapshot` | 스냅샷 기록 (하루 1회) |
| `GET` | `/ops/incidents/drafts` | 초안 수명 — **만료는 기각이 아님** |
| `GET` | `/ops/diagnostics` | 운영 진단 — `?stage=startup\|daily` |
| `GET` | `/ops/validation-plan` | **검증 스프린트 준비** — 담당·증거·병목 |

> **정책 4001-⑥의 실제 검증은 시작할 수 없습니다.** 사람이 줘야 끝나는
> 단계가 3건 남아 있습니다 — 실 Provider 자격 증명, 공식 주소로 나가는
> 길(`api.openai.com`이 프록시에 막혀 있습니다), 검증용 환경. 준비 상태는
> `GET /ops/validation-plan`이 단계별로 말합니다.

## Enterprise Operations Control (TASK-3901, Sprint 39)

CTO 정책 3901-①~⑥ 반영 — 주제는 **통제 장치가 스스로를 속이지 못하게
한다**입니다.

- **`activation-lost` 공식 채택**(정책 3901-①): TASK-3801의 확장 해석이 정식
  계약이 됐습니다. 그 과정에서 **키 결함**을 찾아 고쳤습니다 — 키에 조건
  집합만 넣으면 `완료 → 풀림 → 다시 완료`의 **두 번째 완료가 조용히
  버려집니다.** 되살아난 것은 처음 된 것만큼 중요합니다
- **KPI 임계값 운영 설정**(정책 3901-② · `kpi.threshold.<id>.<good|watch>`):
  **임계값을 올리면 아무것도 나아지지 않았는데 대시보드가 초록이 됩니다.**
  그래서 기본값이 아닌 임계값은 카드가 "운영자 조정값"이라고 말하고,
  **느슨하게 바꾼 것**("초록을 산 것")과 엄격하게 바꾼 것을 가르며, 범위 밖
  값은 막습니다(임계값을 없애는 것은 설정이 아니라 우회입니다)
- **보존 정책**(정책 3901-③ · `retention.<target>.days`): **감사 기록은
  다른 것보다 오래 남아야 합니다**(기본 365일, 이벤트 180일). 감사를 반년
  미만으로 줄이는 것은 보존 정책이 아니라 **감사를 끄는 것**이라 막습니다.
  정리는 `alert-archive`에 편입했고, **아무것도 안 지웠어도 결과를 남깁니다**
- **긴급/일반 채널 분리**(정책 3901-④ · `ALERT_URGENT_*`): 분리의 진짜
  위험은 **침묵**입니다 — 긴급 채널이 없으면 급한 알림만 아무 데도 안 가고
  그 침묵은 "조용하다"로 읽힙니다. **미구성이면 일반 채널로 되돌리고 그
  사실을 말합니다**
- **경보 → 장애 초안 자동 승격**(정책 3901-⑤ · 기본 꺼짐): 자동으로 만드는
  것은 **초안**이지 장애가 아닙니다. 초안은 "이건 장애였을 수 있습니다,
  봐 주세요"라는 질문이고, **MTTR에도 진행 중 장애 수에도 들어가지
  않습니다.** 사람이 확인하면 장애가 되고, **기각하면 사유와 함께** 남습니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/settings` | **운영 설정 현황** — 임계값·보존·긴급 경로·승격 |
| `POST` | `/ops/incidents/promote` | 초안 승격 실행 (기본 꺼짐) |
| `POST` | `/ops/incidents/:id/confirm` | 초안 → 장애 (설명 필수) |
| `POST` | `/ops/incidents/:id/dismiss` | 초안 기각 — **사유 필수** |
| `POST` | `/ops/notifications/test` | 알림 시험 — `level`로 **긴급 경로 확인** |

> **정책 3901-⑥(실 Provider 활성화 검증)은 검증 경로만 확인했습니다.**
> 활성화 0/3 조건이고 `api.openai.com`이 프록시에 막혀 있습니다.

## Enterprise Operations Governance (TASK-3801, Sprint 38)

CTO 정책 3801-①~⑤ 반영 — 주제는 **아무도 보고 있지 않을 때에도
남는다**입니다.

- **활성화 완료 자동 이벤트**(정책 3801-① · `GET /ops/events`): 이력은 **보러
  가야 보입니다.** 그런데 마지막 조건이 채워지는 순간은 대개 아무도 화면을
  보고 있지 않을 때 옵니다 — 방화벽이 열렸거나, 결제가 풀렸거나, CI가 마침내
  초록이 됐을 때. 그 순간을 아무도 모르면 운영은 **이미 켤 수 있게 된 상태로
  며칠을 더 놉니다.** 이벤트는 **경계를 넘을 때만** 나고, 같은 전이는 표의
  유니크 제약이 한 번으로 막습니다. **처음 관측에서는 내지 않습니다**(우리가
  못 보는 동안 이미 그 상태였을 수 있습니다). 그리고 **완료만 알리지
  않습니다** — 풀린 것이 훨씬 급하고, 좋은 소식만 전하는 알림은 아무도
  신뢰하지 않습니다
- **장애 사후 분석**(정책 3801-② · `POST /ops/incidents/:id/analysis`):
  재시작으로 살린 것과 원인을 없앤 것이 목록에서 똑같이 "복구됨"으로 보이면,
  팀은 자기가 **몇 개의 시한폭탄을 안고 있는지** 모릅니다. 닫을 때 임시·영구를
  **반드시 고르게** 하고(기본값을 두면 목록이 거짓말합니다), 임시로 닫힌
  장애는 영구 조치가 적힐 때까지 남습니다. **근본 원인 없이 재발 방지를 적을
  수 없습니다**
- **운영 KPI**(정책 3801-③ · `GET /ops/kpi` · `/admin/kpi`): 판정은 이미 일곱
  군데에 있었고, 문제는 **사람이 일곱 군데를 돌지 않는다**는 것이었습니다.
  **표본이 없으면 0이 아니라 "낼 수 없음"** 이고(MTTR 0분은 "우리는 매우
  빠르다"로 읽힙니다), **좋아 보이는 0에는 주석을 답니다**("장애 0건"은 아무도
  적지 않았다는 뜻일 수도 있습니다). **모르는 지표를 좋음으로 세지
  않습니다** — 절반을 모르는 초록 화면이 가장 위험합니다
- **운영 감사 기록**(정책 3801-④ · `GET /ops/audit`): `/ops/*`의 **변경 요청
  전부**를 가로채기로 남깁니다 — 서비스마다 부르게 하면 다음 엔드포인트에서
  누군가 빠뜨리고, **빠진 감사 기록은 실패하지 않습니다**. **실패한 시도도
  남습니다**(거절된 시도는 그 자체가 신호입니다). 조회는 남기지 않고, 본문은
  **값이 아니라 이름만** 남깁니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/kpi` | **운영 KPI (ADMIN)** — 표본이 없으면 "낼 수 없음" |
| `GET` | `/ops/events` | 운영 이벤트 — 시스템이 관측한 상태 변화 |
| `GET` | `/ops/audit` | 운영 감사 기록 — **실패한 시도 포함** |
| `POST` | `/ops/incidents/:id/analysis` | 장애 사후 분석 (근본 원인·영구 조치·재발 방지) |

> **정책 3801-⑤(실 Provider 활성화)는 이번에도 수행하지 못했습니다.** 활성화
> 0/3 조건이고 `api.openai.com`이 프록시에 막혀 있습니다.

## Enterprise Production Activation History (TASK-3701, Sprint 37)

CTO 정책 3701-①~⑤ 반영 — 주제는 **본 것만 세고, 안 본 것은 안 본 것으로
둔다**입니다.

- **활성화 이력**(정책 3701-① · `GET /ops/activation/history`): `/ops/activation`은
  **지금**에 답하지만, 전환은 몇 주에 걸쳐 조건이 하나씩 채워지는 과정입니다.
  화면을 열 때마다 한 줄씩 쌓으면 같은 문장 수천 줄이 되고 **그 안에서 변화가
  보이지 않으므로**, 상태가 바뀔 때만 새 줄을 만들고 같은 상태면 마지막 관측
  시각만 갱신합니다. 그 시각이 **"3주째 그대로"와 "3주 동안 아무도 안 봤다"를
  가릅니다** — 마지막 확인 이후 구간은 "유지됐다"가 아니라 **"모른다"** 입니다.
  기록이 없으면 `activated`는 `false`가 아니라 **`null`** 입니다
- **운영 스모크**(정책 3701-② · `POST /ops/smoke`): 지금까지의 판정은 전부
  간접 증거였습니다(키 형식 · 주소 · TCP 도달 · DB 성공 기록). 그 넷을 다
  통과하고도 **결제 정지 · 모델 접근 거부 · 버킷 쓰기 권한 없음**은 보이지
  않고, 그런 것은 **불러야만** 보입니다. LLM · OCR · S3를 가장 작은 호출로
  한 번씩 부릅니다. **성공이 곧 통과가 아닙니다** — 공식 주소를 상대로 한
  성공만 통과이고 스텁 상대 성공은 `stubbed`(통과 아님)입니다. S3는 **읽은
  것이 쓴 것과 같아야** 성공입니다. 실 호출은 돈이 나가므로 **사람이 누를 때만**
  돌고 누가 눌렀는지 남습니다(결정 1301-①). 예약 `provider-smoke`도 **같은
  검사**를 돕니다 — 이름이 같은 검사가 둘이면 더 느슨한 쪽이 근거로 쓰입니다
- **활성화 대시보드**(정책 3701-③ · `/admin/activation`): 지금 · 과정 · 증거 ·
  장애를 한 화면에 둡니다. 이 화면이 하지 **않는** 일은 좋아 보이게 만드는
  것입니다 — 스텁 성공은 초록이 아니고, 되돌아간 조건은 붉게 적히며, 아무도
  보지 않은 구간은 그 사실이 적힙니다
- **장애 이력**(정책 3701-④ · `GET/POST /ops/incidents`): **경보와 장애는
  다릅니다** — 경보는 자동으로 뜨는 신호이고, 장애는 사람이 선언한 사건입니다.
  **진행 중인 장애의 지속 시간은 최종값이 아니라 "지금까지"** 이므로 평균에
  넣지 않고, 복구된 것이 하나도 없으면 평균은 **0분이 아니라 "낼 수 없음"**
  입니다. 감지 시간과 복구 시간을 나눠 셉니다(늦게 안 것과 늦게 고친 것은
  고칠 곳이 다릅니다). **복구 방법 없이는 닫히지 않습니다**

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/activation/history` | **활성화 이력 (ADMIN)** |
| `GET` | `/ops/smoke` | 마지막 스모크 결과 — 부르지 않습니다 |
| `POST` | `/ops/smoke` | **운영 스모크 실행 (ADMIN · 실 호출·과금)** |
| `GET` | `/ops/incidents` | 운영 장애 이력 (ADMIN) |
| `POST` | `/ops/incidents` | 장애 기록 (ADMIN) |
| `POST` | `/ops/incidents/:id/resolve` | 복구 기록 — **복구 방법 필수** |

> **정책 3701-⑤(실 Provider 활성화)는 수행하지 못했습니다.** 세 활성화 조건이
> 모두 미충족이고, 라이브 스모크에서 `api.openai.com`이
> `HTTP 403 Host not in allowlist`로 막혔습니다. 그 사실을 "준비됨"으로
> 바꿔 적지 않습니다.

## Enterprise Production Activation (TASK-3601, Sprint 36)

CTO 정책 3601-①~④ 반영 — 주제는 **완료는 셋이 모두 될 때만 완료다**입니다.

- **활성화 세 조건**(정책 3601-① · `GET /ops/activation`): `자격 증명` ·
  `네트워크` · `전환 판정(pnpm cutover)`. **하나라도 아니면 완료가
  아닙니다** — 둘이 충족된 상태는 "거의 다"가 아니라 여전히 전환되지 않은
  상태입니다. 자격 증명은 **형식만** 보고(유효성은 실제 호출이 압니다),
  **점검하지 않은 네트워크는 충족이 아닙니다**
- **요청 추적**(정책 3601-②): 모든 요청에 `x-request-id`를 세우고
  (앞단이 준 값이 있으면 **그대로 쓰고**, `traceparent`가 있으면 그 추적에
  붙습니다) `executions`·`ocr_results`에 `requestId`·`traceId`를 남깁니다 —
  한 요청이 부른 호출들을 묶는 끈이 없으면 "이 요청이 얼마를 썼는가"에 답할
  수 없습니다
- **공지 어댑터 구조**(정책 3601-③): 형식별 파서를 `PRICE_SOURCE_PARSERS`
  한 곳에 모아 **형식이 늘어도 판정은 늘지 않게** 했습니다. `html`·`rss`·
  `jsonfeed`는 **이름은 알지만 아직 어댑터가 없다**고 따로 말합니다 —
  오타를 의심할 일과 어댑터를 요청할 일은 다릅니다
- **CI Job 분리**(정책 3601-④): Core/API와 Web e2e를 **병렬 Job**으로
  나눴습니다. 한 Job이 전부를 돌면 e2e가 늘 때마다 모든 게이트의 답이
  늦어지고, **게이트가 느려지면 사람은 게이트를 안 기다립니다**

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/activation` | **운영 활성화 세 조건 (ADMIN)** |

## Enterprise Production Cutover (TASK-3501, Sprint 35)

CTO 지시 1~6 반영 — 주제는 **키가 틀린 것과 길이 막힌 것은 다르다**입니다.

- **도달 점검**(지시 2·3): 자격 증명 이전의 조건을 봅니다. 키를 넣어도
  방화벽·프록시가 공식 주소를 막고 있으면 전환은 되지 않고, 그때 나오는
  오류는 **키 문제처럼** 보입니다. 판정은 `reachable / blocked /
  **ambiguous**` 셋입니다 — **403은 누가 막았는지 모른다고 말합니다**
  (Provider의 거절일 수도, 프록시일 수도 있습니다)
- **`pnpm cutover`**: 전환 판정을 명령 하나로 확인합니다
  (0 전환 완료 / 1 미완 / **2 판정 불가**). 전환을 *수행*하지 않고 *확인*만
  하며, 통과시키는 우회로는 두지 않았습니다
- **게이트가 게이트를 검증합니다**(지시 4): 워크플로에서 게이트 한 줄이
  사라져도 CI는 초록으로 끝납니다 — 없어진 검사는 실패하지 않기 때문입니다.
  `pnpm check:ci-gates`가 필수 게이트·순서·브라우저 설치 단계를 확인하고,
  **그 단계 자체가 워크플로 안에** 있습니다. 동시 실행 취소·시간 상한·최소
  권한도 함께 넣었습니다
- **공지 어댑터 확장**(지시 5): `csv` 형식 추가(빈 칸을 0으로 읽지 않습니다 —
  0은 "무료"라는 뜻이 됩니다) · **소스가 책임지는 단가 선언**
  (`PRICE_SOURCE_KEYS_<PROVIDER>`) — 공지가 죽었을 때 **그래서 어떤 단가를
  확인하지 못했는지**를 이름으로 말합니다
- **운영 UX**(지시 6): 전환 화면이 **지금 할 일 하나**를 크게 보여 주고,
  도달 점검 결과를 세 상태로 갈라 보여 줍니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/cutover` | 운영 전환 검증 — **도달 점검 결과 포함** |

### 승인된 정책 (CTO 정책 3501-①~⑤)

- **①** 실 Provider 전환은 **운영·Staging에서** 수행합니다 — 개발에서는 판정을
  참고용으로 두고 재촉하지 않습니다(상시 빨간색은 정작 운영의 빨간색까지
  무시하게 만듭니다)
- **②** 공지가 밝힌 발효 시각이 **예약 기본값**입니다 (운영자 수정 가능 ·
  과거 시각은 기본값이어도 거부)
- **③** 최종 승인자는 **다른 ADMIN**으로 유지합니다
- **④** `executions`·`ocr_results`에 **Provider · Endpoint · Base URL · 호출
  시각**을 남깁니다 — 호출하는 **그 자리에서** 남깁니다
- **⑤** `verified`는 **실제 호출 대상**을 근거로 합니다. `baseUrl`이 공식
  주소인 성공만 세고, 옛 기록의 `null`은 "공식이었다"가 아니라 **"모른다"** 입니다

> **아직 끝나지 않은 것**: 지시 2·3의 실제 전환. 이 환경에 Google Cloud·
> OpenAI·AWS 자격 증명이 없고, `api.openai.com`은 프록시에 막혀 있습니다.
> 판정 장치는 그 사실을 `ready: false`로 정직하게 말합니다.

## Enterprise Production Readiness (TASK-3401, Sprint 34)

CTO 지시 1~7 반영 — 주제는 **스텁을 진짜로 세지 않는다**입니다.

- **Provider별 공지 어댑터**(결정 3301-⑤): 공지 주소·형식·토큰을 Provider마다
  따로 둡니다(`PRICE_SOURCE_URL_<PROVIDER>` · `PRICE_SOURCE_FORMAT_<PROVIDER>`
  = `acos` | `flat`). 한 곳이 죽어도 나머지는 읽히고, **전체 상태는 가장 나쁜
  것을 따릅니다** — 셋 중 둘을 읽었다고 "정상"이라 하면 못 읽은 하나가
  사라집니다. **모르는 형식은 짐작해서 읽지 않고** 사유를 남깁니다
- **공지 실패가 길어지면 등급을 올립니다**(결정 3301-⑥): 기본 24시간
  (`PRICE_SOURCE_ESCALATE_AFTER_MS`)을 넘기면 `warning` → `critical`이 되고
  문구에 몇 시간째인지가 붙습니다. **미구성은 승격하지 않고**(미구성과 실패는
  다릅니다), 시작 시각은 경보가 아니라 **실행 이력**에서 셉니다
- **운영 전환 검증** `GET /ops/cutover`(지시 4·5·6): LLM · Vision · S3 · CI 넷을
  `verified / not-production / unverified / not-configured / invalid`로
  판정합니다. **계약 스텁을 상대로 만든 성공 기록을 연결의 증거로 세지
  않습니다** — 라이브에서 이 판정이 "OCR 성공 22건"이 전부 우리 스텁을 상대로
  만들어진 것임을 잡아냈습니다. 연결 순서 판정(`/ops/providers`)도 같은 기준을
  따릅니다
- **GitHub Actions 운영 검증**(지시 6): 워크플로 **파일**과 최근 **실행 결과**를
  따로 봅니다 — 적혀 있는 것과 초록으로 끝나는 것은 다릅니다. 실제로 이
  저장소의 CI는 **13회 연속 실패**하고 있었고(러너에 Playwright 브라우저가 없어
  `pnpm test`가 통째로 죽었습니다), 워크플로에 TypeScript 게이트도 없었습니다.
  둘 다 고쳤습니다
- **문서**: [production-cutover.md](docs/operations/production-cutover.md) 신설,
  배포 체크리스트에 CI 게이트·전환 검증 절차 추가

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/cutover` | **운영 전환 검증 (ADMIN)** — 붙은 상대가 진짜인가 |

## Enterprise Provider Intelligence (TASK-3301, Sprint 33)

CTO 정책 3301-①~④ 반영 — 주제는 **못 읽은 것을 괜찮다고 말하지 않는다**입니다.

- **외부 가격 공지를 읽습니다**(정책 3301-①): `PRICE_SOURCE_URL`의 JSON
  가격표와 우리 표를 대조해 **진짜 "Provider가 단가를 올렸다"**를 잡습니다.
  공지 기반 제안은 출처가 `published`이고 근거에 **공지 주소와 공지가 밝힌 발효
  시각**이 남습니다
- **파싱 실패를 "변경 없음"으로 처리하지 않습니다**: 조용히 지나가면 화면은
  "변경 없음"으로 보이고, 사람은 확인했다고 믿고, 단가는 낡은 채로 돈이
  나갑니다. `partial`(일부만 읽음)까지 **경고를 만들고 사람 확인을 요구**하며,
  못 읽은 항목은 목록으로 남깁니다. 미구성은 실패가 아니므로 제목이 다릅니다
- **시스템 제안은 2단계 승인**(정책 3301-②): `시스템 생성 → ADMIN 승인 → 다른
  ADMIN 최종 승인 → 적용`. 운영에서만 강제합니다 — 사람이 낸 제안은 제안자와
  승인자가 이미 둘이지만, 시스템 제안은 승인자 한 명이 곧 전부이기 때문입니다.
  **최종 승인자는 1차 승인자와 달라야** 합니다
- **예약 취소는 삭제가 아닙니다**(정책 3301-③): `CANCELLED`로 남깁니다. 적용은
  실제로 있었던 일이고, 그 결정을 지우면 "왜 그때 그 단가가 예약됐다가
  사라졌는가"에 아무도 답할 수 없습니다. **발효 전 예약만** 취소할 수 있고
  사유가 필요합니다
- **감지 주기는 Provider별로만**(정책 3301-④): 기본 6시간
  (`PRICE_DETECT_INTERVAL_<PROVIDER>`). **프로젝트별 설정은 거부**하고 사유를
  남깁니다 — 단가는 Provider와의 계약이지 프로젝트의 속성이 아닙니다.
  감지 실행은 **0건도, 건너뛴 것도** 기록합니다: 그래야 "감지 0건"과 "감지를
  안 돌렸다"를 구분할 수 있습니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/ops/pricing/:id/confirm` | **최종 승인 (ADMIN)** — 1차 승인자와 달라야 한다 |
| `POST` | `/ops/pricing/:id/cancel` | **예약 취소 (ADMIN)** — 삭제하지 않는다 |

절차: [ai-cost-governance.md](docs/operations/ai-cost-governance.md) §1-2·§1-3·§1-4·§1-6

## Enterprise 가격 자동화 (TASK-3201, Sprint 32)

CTO 정책 3201-①~⑤ 반영 — 주제는 **자동화는 찾아내고, 사람이 정한다**입니다.

- **가격 변경은 감지 → 승인 → 적용**(정책 3201-①): 예약 점검(6시간)이 기록과
  가격표를 대조해 `DETECTED` 제안을 만들고 **근거**(표본 수·기간·표본 id·차이)를
  붙입니다. 감지가 검토를 대신하지만 **승인과 적용은 언제나 사람**이 합니다 —
  자동 적용을 허용하면 일시적 이상이나 계산 오류가 곧바로 **돈의 기준**을 바꿉니다
- **감지할 수 없는 것을 감지한다고 말하지 않습니다**: Provider의 가격 공지는
  읽을 수 없습니다(비용은 우리가 우리 가격표로 계산합니다). 감지하는 것은
  **기록과 지금 가격표의 불일치**이고, 원인은 낡은 인스턴스·절차 우회·가격표
  오류 셋입니다. **LLM은 입력·출력 단가를 가를 수 없어 숫자를 만들지 않고**
  어긋났다는 사실만 알립니다
- **운영에서는 자기 승인을 차단합니다**(정책 3201-②): 개발에서는 허용하고
  사실만 남깁니다 — 개발에서 절차가 막히면 사람은 코드를 고쳐 우회하고 이력이
  아예 없어집니다(결정 2601-① 교훈). **운영에는 ADMIN 계정이 최소 둘 필요합니다**
- **적용은 결정이고 발효는 시각입니다**(정책 3201-③): `Effective From`으로
  미래 시점을 예약합니다. 예약된 단가는 그 시각까지 **어떤 계산에도 쓰이지
  않고** 화면이 따로 보여 줍니다. **과거 시점은 거부**합니다 — 이미 기록된
  비용을 소급해 다시 해석하게 되고, 맞았던 기록이 불일치로 바뀝니다
- **Forecast는 Alert만 냅니다**(정책 3201-④): 예약 점검이 "이 추세면 예산을
  넘습니다"를 경보하고, 그 문구가 **"이 값으로 호출을 차단하지 않습니다"**를
  직접 말합니다. Budget Gate는 여전히 실제 비용만 봅니다
- **적용 즉시 캐시를 무효화합니다**(정책 3201-⑤): 적용한 인스턴스는 그 자리에서,
  나머지는 Redis pub/sub 신호로. 캐시는 **다음 발효 시각**도 만료로 봅니다 —
  예약을 지나쳐 캐시하면 발효 순간이 조용히 늦어집니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/ops/pricing/detect` | **지금 감지 (ADMIN)** — 제안까지만 만든다 |
| `POST` | `/ops/pricing/:id/apply` | `effectiveFrom`으로 **발효 예약** |

절차: [ai-cost-governance.md](docs/operations/ai-cost-governance.md) §1-2~§1-5

## Enterprise AI 비용 인텔리전스 (TASK-3101, Sprint 31)

CTO 정책 3101-①~④ 반영 — 주제는 **단가는 절차를 거쳐 바뀌고, 기록은 손대지
않는다**입니다. 화면은 관리자 → **AI 비용 관리**(`/admin/costs`, ADMIN 전용).

- **가격표는 검토 → 승인 → 적용 절차를 거칩니다**(정책 3101-①): 단계를 건너뛸
  수 없고, **적용·반려는 끝**입니다 — 되돌리려면 새 제안을 냅니다. 사유는
  제안·반려 모두 필수이고, **0은 허용·음수는 거부**합니다(음수 단가는 지출을
  줄여 예산 상한을 무력화합니다)
- **적용만 계산을 바꿉니다**: 승인은 "적용해도 된다"는 뜻이고, 실제로 계산에
  쓰이기 시작한 시점은 **적용 시각**입니다. 그 시각이 있어야 "언제부터 이 단가로
  계산됐나"에 답할 수 있습니다. 적용된 단가는 LLM Execution과 OCR 비용 **양쪽**에
  쓰입니다
- **제안자와 승인자가 같으면 경고만 남깁니다**: 절차 자체가 막히면 사람은 코드를
  고쳐 우회하고, 그러면 이력이 아예 없어집니다(결정 2601-① 교훈)
- **비용 기록은 수정하지 않습니다**(정책 3101-②, Append Only): 단가가 바뀌어도
  과거 비용은 그대로이고, 검증은 **그 시점에 유효했던 단가**로 대조합니다.
  새 단가로 과거를 대조하면 단가를 한 번 바꿀 때마다 **과거 전체가 "불일치"로
  보고**되고, 무시되는 경보는 없는 경보보다 나쁩니다
- **Forecast는 참고자료입니다**(정책 3101-③): 관측 **3일 미만이면 숫자를 만들지
  않습니다**(고정값 — 열어 두면 "일단 1일로 낮추는" 우회가 생깁니다). **이 값으로
  호출을 막지 않습니다** — 예측으로 막으면 아직 쓰지 않은 돈 때문에 서비스가
  멈춥니다. 예산 관문은 이 모듈을 아예 모릅니다(구조로 지켰습니다)
- **Billing Report는 운영 지표입니다**(정책 3101-④): **회계 청구서를 대체하지
  않습니다.** 응답과 화면에 항상 면책 문구와 **차이의 이유 넷**(미산정·실패
  호출·무료 구간·환율)이 함께 붙습니다 — 이유가 없으면 "우리 숫자가 틀렸다"로
  읽히고, 숫자만 있으면 누군가 그것을 청구서로 다룹니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/ops/pricing` | **제안 목록 + 실효 가격표 (ADMIN)** — 줄마다 출처 |
| `POST` | `/ops/pricing` | **단가 변경 제안 (ADMIN)** — 사유 필수 |
| `POST` | `/ops/pricing/:id/{review,approve,apply,reject}` | **단계 진행 (ADMIN)** |
| `GET` | `/ops/cost-forecast` | **월말 예측 (ADMIN)** — 참고자료 |
| `GET` | `/ops/billing?from=&to=` | **운영 비용 리포트 (ADMIN)** — 회계 아님 |

절차: [ai-cost-governance.md](docs/operations/ai-cost-governance.md)

## Enterprise AI 운영 (비용·관측 편입, TASK-3001, Sprint 30)

CTO 결정 2901-①~④ 반영 — 주제는 **AI 지출을 하나로 보고, OCR도 같은 눈으로
관측하는 것**입니다.

- **예산은 "LLM 지출"이 아니라 "AI 지출 총액"입니다**(결정 2901-④): OCR도
  호출당 과금되는 AI 호출이므로 같은 상한 안에 들어옵니다. 그러지 않으면 실
  OCR 엔진을 붙인 순간부터 **예산 밖에서 돈이 나갑니다.** 원장은 성격대로
  둘(LLM Execution · OCR 실행 이력)로 유지하고 **지출만 합칩니다**
- **예산을 넘기면 OCR도 막힙니다**: LLM과 같은 관문(호출 전 검사·429·기록
  없음)이고, **무엇이 막혔는지** 문구가 말합니다
- **단가는 코드 선언 중앙 정의**(`DEFAULT_OCR_PRICING`): `google-vision`은
  1,000단위당 $1.50. **무료 구간은 반영하지 않습니다** — 빼면 예산이 낙관적으로
  보이고, 남은 무료 구간을 우리가 알 수 없습니다
- **비용 문제를 네 가지로 가릅니다**: `unpriced`(가격표 없음 — 상한 무력) ·
  **`unrecorded`(산정 가능했는데 기록 없음)** · `mismatch` · `missing-usage`.
  `null`을 0으로 보고 "기록 $0"이라 말하면 기록된 값이 다르다는 뜻이 되어
  사실과 어긋납니다
- **관측은 같은 기준, 표는 따로**: OCR 성공률·지연·비용을 LLM과 같은 판정
  함수로 보되 같은 표에 섞지 않습니다(토큰·Failover 통계를 흐립니다).
  **장애 경보는 같은 종류**입니다 — 운영자에게는 "AI 경로가 죽었다"는 같은 사건
- **완료 판정은 `/ops/providers`의 `connected`**(결정 2901-①) · **OCR 운영
  표준은 Google Cloud Vision**(결정 2901-②) · **근거 기한 30일**(결정 2901-③)

절차: [provider-rollout.md](docs/operations/provider-rollout.md) §4

## Enterprise AI Provider 운영 연결 (TASK-2901, Sprint 29)

CTO 결정 2801-①~⑤ 반영 — 주제는 **실 Provider를 순서대로 붙이고, 붙었는지를
사실로 확인하는 것**입니다. 확정된 순서는 **OpenAI → Anthropic → Gemini →
Vision → OCR**입니다(결정 2801-⑤).

- **연결 순서를 값으로 둡니다**: `/ops/providers`(ADMIN)가 단계별 상태와
  **다음에 붙일 단계**를 알려줍니다. 순서가 문서에만 있으면 "지금 어디까지
  붙었는가"에 아무도 답할 수 없습니다
- **`unverified`를 `connected`로 세지 않습니다**: 키 형식이 맞다는 것은 오타가
  없다는 뜻일 뿐입니다. `connected`의 근거는 **성공한 실행 기록**이고, 그
  근거에는 기한(최근 30일)이 있습니다 — 2년 전 성공으로 "지금도 붙어 있다"고
  말할 수 없습니다
- **OCR 운영 표준 엔진을 붙였습니다**: `OCR_PROVIDER=google-vision`
  (Google Cloud Vision `images:annotate`). 신뢰도를 **지어내지 않고**(주지
  않으면 `null`), 오류를 **한 덩어리로 뭉치지 않습니다**(키·할당량·장애·이미지
  문제는 사람이 할 일이 전혀 다릅니다)
- **조용히 mock으로 대체하지 않습니다**: 그전에는 `OCR_PROVIDER=google`(오타)이
  경고 한 줄만 남기고 **가짜 OCR로 운영을 돌렸습니다.** 이제 운영에서는 기동이
  중단됩니다 — 이미지에서 읽지도 않은 텍스트로 조립된 상품이 검수를 통과하는
  것이 가장 위험한 조용한 실패입니다
- **Vision은 별도 키가 없습니다**: LLM Gateway를 그대로 타므로 앞 세 단계 중
  하나가 붙어 있어야 합니다. `VISION_PROVIDER`는 더 이상 읽지 않고, 값이 남아
  있으면 환경 검증이 그 사실을 경고합니다

절차: [provider-rollout.md](docs/operations/provider-rollout.md)

## Enterprise 거버넌스 지능화 (TASK-2801, Sprint 28)

CTO 결정 2701-①~⑤ 반영 — 주제는 **경보가 어디를 봐야 할지 말해 주는 것**입니다.
TASK-2701이 "늘었으면 부른다"를 만들었고, 이번에는 그 부름이 **어느
프로젝트에서, 무엇이 새로 위반됐는지**까지 담게 만들었습니다.

- **되살리기 권한은 `EDITOR` 유지**(결정 2701-①): ADMIN으로 올리지
  않았습니다 — 콘텐츠를 고치는 사람이 내린 것을 되살릴 수 없으면 사람들은
  새 콘텐츠를 만들어 우회하고, 그러면 왜 내렸는지가 끊깁니다. 되살리기를
  **별도 API로 분리하지도 않았습니다**(분리하면 권한·감사 이력이 두 갈래가
  됩니다)
- **발행 시각은 둘**(결정 2701-②): `publishedAt`은 **최초** 발행 시각으로
  그대로 두고, `lastPublishedAt`을 신설했습니다. 재발행이 공식 절차가 된 뒤
  최초 시각 하나로는 **"지금 언제부터 나가 있는가"**에 답할 수 없습니다.
  값이 없으면 **모르는 것**이므로 화면은 "재발행 없음"이 아니라 "마지막 발행
  시각 미기록"이라고 말합니다
- **프로젝트별 예약 스캔**(결정 2701-③): 프로젝트를 하나씩 훑고 **전체 범위는
  그 합**으로 만듭니다 — 따로 한 번 더 훑으면 읽은 시점이 달라 전체와
  프로젝트별 숫자가 어긋날 수 있습니다
- **프로젝트별 Alert와 독립 Cooldown**(결정 2701-④): 범위마다 기준선·경보
  키가 따로입니다. 뭉치면 ⓐ 한 프로젝트가 나아지고 다른 프로젝트가 나빠질 때
  총량이 그대로여서 **아무 경보도 오지 않고** ⓑ 프로젝트 A의 스캔이 **B의
  경보를 해소해 버립니다.** 해소 범위도 이번에 판정한 범위로 좁힙니다
- **경보에 증가 수와 새로 위반된 콘텐츠(최대 10건)**(결정 2701-⑤): 숫자만
  오는 경보는 "어디를 봐야 하나"에 답하지 않습니다. **증가 수와 새로 위반된
  수는 다를 수 있으므로**(2건이 생기고 1건이 해소되면 총량은 1건 증가) 둘을
  따로 말하고, 10건이 넘으면 생략 건수를 밝힙니다

절차: [content-governance.md](docs/operations/content-governance.md) §4.2 · §5.1

## Enterprise 거버넌스 자동화 (TASK-2701, Sprint 27)

CTO 결정 2601-①~⑤ 반영 — 주제는 **사람이 누르지 않아도 도는 거버넌스**입니다.
TASK-2601이 스캔 도구를 만들었고, 이번에는 그것을 **예약으로 돌리고, 늘었을
때만 부르고, 큰 프로젝트에서도 정확하게** 만들었습니다.

- **이미 나간 위반의 공식 절차**(결정 2601-①): **`PUBLISHED` → `ARCHIVED` →
  수정 → 재발행**. 그런데 `ARCHIVED`는 종결 상태여서 그 절차를 밟을 수
  없었습니다 — **`ARCHIVED` → `DRAFT` 되살리기를 열었습니다.** 절차를 정해
  두고 코드가 막고 있으면 사람은 새 콘텐츠를 만들어 우회하고, 그러면 왜
  내렸는지가 새 콘텐츠에 남지 않습니다. **발행으로 직행하는 길은 열지
  않았습니다** — 되살린 것은 `REVIEW`를 거쳐야 하고, 그래야 **게이트가 다시
  돕니다.** 별도 상태(`SUSPENDED`)는 만들지 않았습니다
- **예약 스캔**(결정 2601-②): 매일 03:50 로컬. 보관 정리(04:00)보다 **앞에**
  둡니다 — 스캔이 남긴 기록을 보관이 곧바로 치우면 방금 만든 것을 못 봅니다
- **늘었을 때만 부른다**(결정 2601-③): 첫 스캔은 **기준선**(규칙을 처음 켠
  직후 전량을 경보로 만들면 아무 뜻이 없습니다) · 늘면 경보 · 같으면 조용 ·
  줄면 조용(기존 경보는 유지) · 0이 되면 해소. **경보를 만들지 않은 실행도
  기록**합니다 — "돌았지만 조용했다"와 "돌지 않았다"는 다릅니다
- **페이지**(결정 2601-④): `?offset`·`?limit`은 **목록만** 자르고
  **`summary`는 항상 전체 기준**입니다. 판정은 전량을 하되 내부에서 커서로
  나눠 읽습니다(`skip`은 읽는 도중 새 콘텐츠가 생기면 한 건을 두 번 세거나
  건너뜁니다)
- **규칙 캐시는 Request Scope만**(결정 2601-⑤): 스캔 한 번에 규칙을 한 번만
  읽습니다. **전역 캐시는 두지 않습니다** — 규칙을 고친 운영자가 언제
  반영되는지 알 수 없게 되면 규칙을 신뢰할 수 없습니다

절차: [content-governance.md](docs/operations/content-governance.md) §4.2 · §5.1

## Enterprise 거버넌스 운영 (TASK-2601, Sprint 26)

CTO 결정 2501-①~⑤ 반영 — 주제는 **켜 놓은 규칙을 운영하는 것**입니다.
TASK-2501이 발행 게이트를 켰고, 이번에는 그것을 **켜기 전에 세어 보고, 켠 뒤에
정리하는** 도구를 붙였습니다.

- **Preflight Scan**(결정 2501-①): 규칙을 처음 켜면 이미 `REVIEW`에 있던
  콘텐츠들이 위반을 담고 있을 수 있고, 그러면 **발행이 줄줄이 막힙니다.**
  켜기 전에 세어 봅니다. **상태를 바꾸지 않고, 자동으로 고치지 않고, 판정
  기록도 남기지 않습니다** — 훑어본 것을 발행 시도로 기록하면 이력이 사실과
  어긋납니다. 화면에도 "한 번에 고치기" 버튼이 없습니다
- **이미 나간 위반을 따로 셉니다**: `blocked`(발행 시 막힐 것)와
  `publishedViolations`(**이미 발행됨**)를 나눕니다 — 발행 게이트는 나가는
  것을 막지만 **이미 나간 것에는 아무 힘이 없습니다.** 섞어 세면 "위반 5건"이
  무슨 뜻인지 알 수 없습니다. 목록에서도 이미 나간 것이 먼저 옵니다
- **검사별 집계**로 무엇을 먼저 고칠지 알려줍니다. 목록을 자를 때는 **요약의
  숫자는 자르기 전 전체**이고, 잘랐다는 사실과 생략 건수를 문구에 적습니다
- **판정 기록 90일 보관**(결정 2501-⑤): 경보(1302-④)·Dead Letter(1501-③)와
  같은 정책입니다. **삭제하지 않습니다.** 기준은 **작성 시각**입니다 — 판정
  기록에는 해소라는 개념이 없습니다. 예약 정리 작업(`alert-archive`)에서 함께
  돌립니다(작업을 새로 만들면 같은 성격의 정리가 서로 다른 시각에 돌아 무엇이
  남았는지 흐려집니다). 보관된 것도 `?includeArchived=1`로 볼 수 있습니다 —
  **볼 길이 없으면 보관이 사실상 삭제입니다**
- **하지 않기로 한 것을 테스트로 고정**(결정 2501-②③④): 금지어 단어 경계·예외
  목록 없음(`최고`를 등록하면 `최고급`도 걸립니다 — 넓게 걸고 사람이 판단합니다) ·
  READY는 Advisory 유지(**강제 차단은 `PUBLISHED`뿐**) · 규칙 스코프는 GLOBAL만.
  하지 않기로 한 일은 코드에 흔적이 없어서 나중에 누가 되살려도 아무도 모릅니다

절차: [content-governance.md](docs/operations/content-governance.md) §3.1 · §4.1 · §6

## Enterprise 콘텐츠 거버넌스 (TASK-2501, Sprint 25)

주제는 **발행되는 것을 검사하는 것**입니다. Sprint 4부터 금지어·규칙 검사는
있었지만 **Product Object의 READY 전환에만** 걸려 있었고, 세상에 나가는
Content의 제목·본문에는 아무 검사가 없었습니다 — 발행 조건은 "REVIEW 상태이며
제목과 본문이 비어 있지 않다"뿐이었습니다. 상품을 검사하고 콘텐츠를 검사하지
않는 것은 **재료를 검사하고 완성품은 안 보는 것**과 같습니다.

- **발행 게이트**: `PUBLISHED` 전이에만 걸립니다. 금지어·필수 고지·제목/본문이
  실패하면 **발행을 막습니다**. 검토를 요청하는 것(`REVIEW`)과 세상에
  내보내는 것은 다르므로 다른 전이는 막지 않습니다
- **금지어는 제목과 본문을 모두** 봅니다(READY 판정은 상품 제목·브랜드·OCR만
  봤습니다). 스캔 규칙은 **READY 판정과 같은 함수**입니다 — 상품에서는 걸리는
  말이 콘텐츠에서는 안 걸리면 어느 쪽도 믿을 수 없습니다. 메시지는
  **어디에 몇 건**인지 말합니다(고칠 수 있어야 합니다)
- **필수 고지**: 분류별로 요구합니다(모든 상품에 모든 고지를 붙이면 본문이
  고지문으로 덮이고 아무도 읽지 않습니다). 공백·줄바꿈 차이는 무시합니다
- **경보와 차단을 구분**합니다: 근거 상품 연결이 끊긴 것과 관련 규칙이 있는
  것은 `주의`로 드러내되 막지 않습니다. 막는 항목은 응답의 `blocking`으로
  밝힙니다 — 화면이 "주의인데 왜 막혔지"를 추측하지 않게
- **미설정과 형식 오류를 구분**합니다: 둘 다 `주의`(막지 않음)지만 해야 할
  일이 다릅니다. 형식이 틀린 규칙을 **빈 목록으로 읽지 않습니다** — 그러면
  "위반 없음"이 되어 거짓 통과가 됩니다
- **판정을 기록**합니다(`content_governance_checks`, 삭제하지 않음).
  **그때의 기준**(금지어 수·적용 고지 id)을 함께 남깁니다 — 규칙은 나중에
  바뀌므로 "왜 이게 발행됐지"에 답하려면 그때의 기준이 있어야 합니다.
  **막힌 기록도** 남습니다 — 없으면 "왜 이렇게 늦게 발행됐지"에 답할 수 없습니다
- **미리보기와 게이트가 같은 판정 함수**를 부릅니다(`GET …/governance`) —
  화면이 "발행 가능"이라 했는데 누르면 막히는 상태를 구조적으로 없앴습니다

절차: [content-governance.md](docs/operations/content-governance.md)

## Enterprise 운영 준수 (TASK-2401, Sprint 24)

CTO 결정 2301-①~④ 반영 — 주제는 **같은 사실을 두 곳이 따로 판정하지 않게
하는 것**입니다. 화면마다 답이 다르면, 어느 쪽을 믿어야 할지 아무도 모릅니다.

- **복구 판정의 단일 원천**(결정 2301-①):
  `/ops/readiness`의 `recoverable`이 유일한 원천이고, 배포 체크리스트는 같은
  계층(`RecoveryEvaluationService`)을 호출해 **결론만 옮깁니다.** 이전에는
  배포 체크리스트가 순환 의존을 피하려고 **백업·복원 이력 개수**로 대신
  판정했고, 그래서 이력이 있으면 "복구 가능"으로 읽혀 **한 화면은 복구 가능,
  다른 화면은 복구 불가**가 될 수 있었습니다. 모듈 의존을 Health → Ops
  한 방향으로 정리해 순환 없이 같은 함수를 부릅니다
- **스키마가 코드보다 앞선 상태는 경보로**(결정 2301-②): 최초 관측은 `주의`,
  **7일을 넘기면 `심각`**. 되돌린 배포는 흔하고 직후에 사람을 부를 일은
  아니지만, **일주일이 지나도 그대로라면 되돌린 것이 아니라 잊은 것**입니다.
  **배포는 막지 않습니다** — 막으면 되돌린 배포를 다시 되돌릴 수 없습니다.
  경과는 경보의 `firstRaisedAt`으로 셉니다(경보는 삭제하지 않으므로 그 시각이
  곧 "처음 본 때"입니다 — 관측 기록용 테이블을 따로 두지 않았습니다)
- **S3 전환 후 Versioning 조회 실패는 실패**(결정 2301-③): 전환 전에는
  `직접 확인`, 전환 후에는 **실패(배포 차단)**입니다. Amazon S3는 조회를
  지원하므로, 못 읽는 것은 **저장소의 한계가 아니라 `s3:GetBucketVersioning`
  권한이 빠졌다는 뜻**입니다. 같은 상태에 같은 판정을 주면 전환의 의미 절반이
  사라집니다
- **`pendingMigrations`의 공식 의미**(결정 2301-④): **실제 미적용 개수**입니다.
  확인하지 못하면 `0`이 아니라 `null`(화면에는 `확인 불가`)입니다. 여기서
  결함 하나를 더 고쳤습니다 — **적용 중 실패한 행이 있으면 미적용 목록을
  비워** `pendingMigrations`가 0으로 보고됐습니다. 무엇을 먼저 알릴지(실패
  우선)와 무엇이 사실인지는 다릅니다

## Enterprise 배포 거버넌스 (TASK-2301, Sprint 23)

CTO 결정 2201-①~④ 반영 — 주제는 **경계를 문서가 아니라 판정으로 만드는 것**
입니다. "운영 담당자가 한다"고 적어 두는 것과, 하지 않았을 때 **배포가 막히는**
것은 다릅니다.

- **스키마도 운영 담당자가**(결정 2201-①): 저장소·IAM에 이어 DB 스키마까지
  같은 경계. 애플리케이션은 **적용하지 않고 검증만** 합니다. 검증만 한다는 것은
  **검증이 실제로 작동해야 한다**는 뜻이라, 실패 행만 세던 방식을 버리고
  **마이그레이션 디렉터리와 적용 기록을 대조**합니다 — 적용하지 않은
  마이그레이션은 실패 행조차 남기지 않아, 실패 행만 세면 "미적용 없음"이라는
  **거짓 통과**가 나왔습니다
- **자동 복구는 만들지 않습니다**(결정 2201-②): 원격 대조 실패는 Critical
  Alert만. 자동으로 다시 올리면 로컬 덤프가 온전한지 확인하지 않은 채
  **틀린 사본을 더 확실하게** 만들 수 있고, 사라진 이유를 모르는 채 올리면
  같은 일이 반복됩니다. 경보 문구에 **수동 복구**임과 절차 위치를 적습니다
- **우회 플래그를 두지 않습니다**(결정 2201-③): `STORAGE_PROVISIONING`은
  추가하지 않고 정책은 `NODE_ENV`만 봅니다. 설정해도 무시됨을 테스트로 고정
- **운영 표준 배포 체크리스트**(결정 2201-④):
  [deployment-checklist.md](docs/operations/deployment-checklist.md).
  **버킷 · IAM · 버전 관리 · 백업 버킷 · 재해 복구 판정**을 체크리스트 항목으로
  승격해 운영에서 **배포를 막습니다**. 문서로만 있는 체크리스트는 "확인했다고
  치는" 절차가 됩니다

## Enterprise 운영 준비 (TASK-2201, Sprint 22)

CTO 결정 2101-①~④ 반영 — 주제는 **운영에 넘길 수 있는 상태**입니다. 시스템이
스스로 준비하던 것을 놓고, **무엇이 필요한지 말하고 기다리는** 쪽으로 바꿉니다.

- **수동 대조는 최근 3건까지**(결정 2101-①): 자동(주 1회)은 1건 그대로입니다.
  주기적으로 도는 것은 비용이 반복되므로 최소로 두고, 사람이 필요할 때 한 번
  더 보는 쪽에만 폭을 줍니다. **상한을 두는 이유**는 "전부"를 허용하면 이력이
  쌓인 뒤 한 번의 클릭이 예상치 못한 전송 비용이 되기 때문입니다.
  **하나라도 실패하면 실패**입니다 — 3건 중 2건이 온전해도 잃은 1건은 그
  시점으로 되돌아갈 수 없다는 뜻이라, 평균을 내면 그 사실이 사라집니다
- **관측 창 상향은 Warning**(결정 2101-②): 상향은 유지하되 Readiness 항목
  `사슬 관측 창 설정`에 주의로 드러냅니다. **기동은 막지 않습니다** — 판정
  설정 하나 때문에 서비스가 뜨지 않으면 안 됩니다. 화면 한 줄로만 두면 아무도
  고치지 않으므로 **드러내되 세우지는 않는** 자리를 골랐습니다. 해석할 수 없는
  값도 같은 취급입니다(무시하되 무시했다고 말합니다)
- **CI 게이트 위치 고정**(결정 2101-③): Build 이후 유지. 앞으로 옮기면
  검증이 모듈을 못 찾아 **조용히 exit 2**가 되므로, 순서를 테스트로 고정했습니다
- **버킷·IAM은 운영 담당자가**(결정 2101-④): 운영에서 애플리케이션은 **버킷을
  만들지도, 정책을 걸지도 않습니다.** 오타 하나로 아무도 모르는 버킷이 생기고,
  운영자가 콘솔에서 조인 권한이 재기동마다 풀리기 때문입니다. 없으면 **누가
  무엇을 해야 하는지**까지 말합니다. 개발에서는 지금처럼 앱이 준비합니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/ops/backup/verify-remote?count=3` | **원격 사본 대조 (ADMIN)** — 수동은 최대 3건 |

## Enterprise 운영 자동화 (TASK-2101, Sprint 21)

CTO 결정 2001-①~⑤ 반영 — 2001에서 만든 판정을 **사람이 기억하지 않아도 도는
것**으로 바꿉니다. 규칙은 있는데 아무도 누르지 않으면 규칙이 없는 것과 같습니다.

- **사슬 관측 창 설정**(결정 2001-① · `BACKUP_CHAIN_WINDOW_HOURS`, 기본 24시간):
  **최소는 백업 간격의 4배**이고, 그보다 짧게 두면 자동으로 올리고 **올렸다고
  화면에 적습니다.** 창이 간격의 4배도 안 되면 창 안에 백업이 서너 개뿐이라
  한 번만 걸러도 판정이 뒤집힙니다 — 표본이 없는 판정은 잡음입니다
- **원격 대조 주 1회 자동**(결정 2001-②): 예약 점검 `remote-verify`가
  **마지막 백업 1건만** 내려받아 SHA-256을 대조합니다. **운영에서만** 켜집니다 —
  개발이 전송 비용을 낼 이유가 없습니다. 결과는 `backup_runs`에 남고, 화면과
  경보는 **그 기록을 읽습니다**(조회할 때마다 내려받으면 화면을 여는 것만으로
  돈이 나갑니다). **주기의 2배를 넘긴 성공은 통과로 두지 않습니다** — 예약이
  두 번 걸렀다면 그때의 결과는 지금의 사실이 아닙니다
- **`_major_` 파일명 규칙 + CI 교차 검증**(결정 2001-③): 매니페스트는 **잊기
  쉽고**(파일을 만들고 목록에 넣는 것을 잊습니다), 파일명은 **되돌리기
  쉽습니다**(이름을 바꾸면 지정이 사라집니다). 둘을 합집합으로 쓰고,
  `pnpm check:major-migrations`가 어긋남을 CI에서 막습니다
- **재기동 후 확인 절차**(결정 2001-④): 자동 등록은 기동 시 1회만 일어납니다.
  그 정책을 유지하는 대신 결과를 화면에 남깁니다 — **확인하지 못한 경우는
  `확인 불가`**이고, "등록할 것이 없었다"와 구분됩니다
- **Amazon S3 운영 전환 계획**(결정 2001-⑤):
  [s3-migration.md](docs/operations/s3-migration.md) — Sprint 21 완료 목표.
  저장소를 바꾸는 것보다 **보호 상태를 조회할 권한**을 빠뜨리지 않는 것이 핵심입니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/ops/checks/run?job=remote-verify` | **원격 대조 예약 점검 실행 (ADMIN)** |

## Enterprise 백업 무결성 (TASK-2001, Sprint 20)

CTO 결정 1901-①~⑤ 반영 — 지금까지는 **남은 기록**만 봤습니다. 이번에는
**남지 않은 것**을 봅니다.

- **백업 사슬 연속성**: 개별 백업이 모두 성공이어도 사슬은 끊길 수 있습니다.
  실패는 이력에 남지만 **돌지 않은 백업은 아무 데도 기록되지 않기** 때문에,
  서버가 멈춰 있던 구간은 이력만 보면 전부 성공으로 보입니다. 그래서 **있어야
  할 개수와 실제 개수를 비교**하고, 공백이 간격의 2배를 넘으면 **복구 필수
  항목이 실패**합니다 — 그 구간은 되돌아갈 수 없습니다
- **원격 사본 무결성**: 올렸다는 **기록**과 사본이 실제로 **있다**는 것은
  다릅니다. 원격 사본을 내려받아 SHA-256을 대조합니다. **전송 비용이 들어
  기본으로 돌지 않으며**(결정 1301-⑤의 연장), 확인하지 않은 상태는 통과가
  아니라 `직접 확인`입니다
- **운영 저장소 표준 = Amazon S3**(결정 1901-③): 운영에서 다른 엔드포인트면
  **실패**입니다. 다만 **개발자에게 S3를 요구하지 않습니다** — 개발에서
  개발 저장소를 쓰는 것은 정상입니다
- **DB 규모 재평가 신호**(결정 1901-④): 10 · 50 · 100GB에 도달하면 백업 성능
  기준을 **실측으로 다시 재라고** 알립니다. 기준마다 경보 키가 달라 10GB를
  해소하고 50GB에서 다시 알립니다. **기준을 자동으로 바꾸지는 않습니다**
- **Major Migration만 자동 등록**(결정 1901-①): 컬럼 하나 추가할 때마다
  리허설을 요구하면 **부를 일이 아닌데 부르는 것**이고, 그러면 정작 불러야 할
  때 오지 않습니다. `apps/api/prisma/major-migrations.json`에 지정된 것만
  자동 등록하고, `dr-change`·`pitr-adoption`은 운영자가 직접 등록합니다
- **중복 등록 금지**(결정 1901-⑤): 같은 `trigger`가 미해소면 `409`. 리허설
  1회로 함께 해소되므로 쌓을 이유가 없습니다
- **삭제 금지, 취소만**(결정 1901-②): `cancelledBy`·`reason`이 필수이고,
  취소된 요구는 **사유와 함께 남습니다.** 지운 요구는 왜 지웠는지 남지 않지만
  취소는 남습니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/ops/backup/verify-remote` | **원격 사본 대조 (ADMIN)** — 전송 비용이 듭니다 |
| `POST` | `/ops/drills/requirements/:id/cancel` | **요구 취소 (ADMIN)** — `{ cancelledBy, reason }` |

## Enterprise 복구 보증 (TASK-1901, Sprint 19)

CTO 결정 1801-①~⑤ 반영 — 관측만 하던 값에 기준을 붙이고, 판정이 미치지 않던
곳까지 같은 규칙을 넓히고, 달력에만 묶여 있던 리허설을 **변경에 반응하게**
합니다.

- **백업 소요 시간 기준**(결정 1801-①): 2초 미만 정상 / 2~10초 주의 /
  **10초 초과 연속 3회** 경보 / 30초 초과 심각. 연속 3회를 요구하는 이유는
  **한 번 느린 것은 흔하기 때문**입니다. **자동으로 간격을 바꾸지 않습니다** —
  시스템이 스스로 백업을 드물게 만들면 손실 구간이 조용히 늘어납니다
- **백업 버킷 보호**(결정 1801-③): 이미지 버킷과 같은 규칙으로 판정하고,
  문구에 **어느 버킷 이야기인지**를 넣습니다
- **운영 저장소 표준 = Amazon S3**(결정 1801-④): MinIO·s3rver는 개발
  전용입니다. 운영에서 다른 엔드포인트면 경고합니다
- **변경 후 즉시 추가 리허설**(결정 1801-⑤): DR 절차 변경 · DB 대규모 변경 ·
  PITR 도입이 등록되면 **기한이 남아도 실패**로 바뀝니다. **성공한 리허설만**
  이 요구를 해소합니다
- **배포 게이트에는 넣지 않습니다**(결정 1801-②): 리허설이 밀렸다는 이유로
  긴급 배포가 막히면 안 됩니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/ops/drills/require` | **변경 사건 등록 (ADMIN)** |
| `GET` | `/ops/drills/requirements` | **변경 사건 목록 (ADMIN)** |

## Enterprise 운영 플랫폼 (TASK-1801, Sprint 18)

CTO 결정 1701-①~⑤ 반영 — **판정만 하던 것을 지키게 만듭니다.**

- **백업 주기 1시간**(결정 1701-①): 시각 기반에서 간격 기반으로 바뀌어
  **최대 손실 구간이 24시간 → 2시간**이 됐습니다. 복구 절차는 그대로입니다.
  **손실 한도 목표가 간격을 따라갑니다**(간격 × 2) — 간격만 바꾸고 목표를
  묶어 두면 백업이 오래 멈춰도 "정상"으로 보입니다
- **백업 전용 버킷**(결정 1701-②): `BACKUP_BUCKET`(기본 `<S3_BUCKET>-backups`)
  으로 이미지와 분리합니다. 백업 버킷에는 **공개 읽기 정책을 걸지 않습니다** —
  덤프가 공개되면 데이터베이스 전체가 공개되는 것과 같습니다
- **Versioning 운영 필수 · Replication 권장**(결정 1701-③): 운영에서 버전 관리가
  꺼져 있으면 **실패**, 복제는 주의입니다. **조회가 불가능한 저장소는
  `직접 확인`을 유지**합니다 — 확인하지 못한 것을 "꺼짐"으로 단정하지 않습니다
- **복구 리허설 분기 1회**(결정 1701-⑤): 리허설은 사람이 하고, 시스템은
  **한 사실을 기록**하고 안 하면 드러냅니다. **실패한 리허설도 기록합니다** —
  절차가 깨졌다는 것을 사고 전에 알아낸 것이라 더 값집니다. 수행자는 필수이며,
  리허설이 밀린 것은 복구 가능 판정을 막지 않습니다

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/ops/drills` | **리허설 기록 (ADMIN)** — `{ ok, performedBy, findings? }` |
| `GET` | `/ops/drills` | **리허설 이력 (ADMIN)** |

## Enterprise 백업·재해 복구 (TASK-1701, Sprint 17)

"백업이 있고 복원된다"(1601) 다음의 세 질문 — **덤프가 온전한가 · 같은 곳에만
있지 않은가 · 얼마를 잃고 얼마나 걸리는가**.
절차는 [disaster-recovery.md](docs/operations/disaster-recovery.md), 백업 방식
검토는 [backup-strategy.md](docs/operations/backup-strategy.md).

- **Backup Integrity**: 백업 직후 `pg_restore --list`로 목차를 읽고 SHA-256을
  기록합니다. **읽히지 않는 덤프는 복구 불가**로 판정합니다 — 크기가 정상이어도
  복원할 수 없는 파일이면 복구 지점이 아닙니다
- **Offsite Replication**(`BACKUP_OFFSITE=on`): 덤프를 오브젝트 저장소에도
  올립니다. 복제 실패가 백업을 실패시키지는 않되(덤프는 이미 있습니다) 화면에
  드러납니다. 원격 키는 노출하지 않고 **있는지만** 알립니다
- **RPO · RTO**: RPO는 마지막 백업 이후 경과, RTO는 **실제 복원 검증에 걸린
  시간(측정치)**입니다. 다만 **하한**입니다 — 장애를 알아차리고 결정하는 시간은
  포함하지 않으며, 측정치가 없으면 통과로 세지 않습니다
- **복원 대상 강제 분리**(결정 1601-②): 복원 대상이 운영 DB와 같으면
  **기동하지 않습니다**. 자격 증명이 달라도 같은 DB는 같은 DB로 봅니다
- **`BACKUP_DIR` 운영 필수**(결정 1601-①): 미설정이면 **기동하지 않습니다** —
  백업이 컨테이너와 함께 사라지는 구성으로 운영을 시작할 수는 없습니다
- **이미지 저장소 보호**(결정 1601-④): 버전 관리·복제 상태를 체크리스트에
  표시합니다. **애플리케이션은 이미지를 직접 백업하지 않으며**, 저장소가 알려
  주지 않으면 `직접 확인`으로 남깁니다
- **WAL·PITR·증분**(결정 1601-③): 이번 Sprint는 **검토만** 했습니다 — 현재
  데이터 규모에서는 백업 주기 단축이 PITR보다 효과가 큽니다

## Execution Domain (TASK-0601, Sprint 6)

모든 LLM 호출(Content Generation · Analysis · Vision · 개발용 API)은 호출 1건당
**Execution 1건**을 기록합니다 — Provider/Model/Token/Cost(USD)/Latency/Status.
기록 실패는 호출을 실패시키지 않습니다 — [docs/architecture/execution.md](docs/architecture/execution.md)

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `GET` | `/executions?feature=&limit=` | LLM 호출 이력 (최신순) — feature: `content-generation` `product-analysis` `vision-analysis` `dev` |
| `GET` | `/executions/stats?from=&to=` | **Dashboard 집계 (TASK-0602)** — 호출 수·성공/실패율·토큰·비용·지연을 전체 + feature/provider/model별 제공 |
| `GET` | `/executions/timeline?interval=hour\|day\|week&…` | **시간 축 집계 (TASK-0605)** — 같은 지표를 시간 버킷으로, feature/provider/model 필터 지원 |

웹: **`/executions` 실행 대시보드 (TASK-0701 · 필터 TASK-0702)** — KPI 카드(성공률은
UI에서 %) · Timeline Chart(hour/day/week, 빈 버킷 UI 보간) · **Dashboard Filter**
(Feature/Provider/Model/From/To) · Feature/Provider/Model 통계 테이블.
hour 조회는 최대 31일(CTO 결정). 웹 스모크 테스트(Playwright)가 `pnpm test`
품질 게이트에 포함됨.

## Memory — 표준 Structured Memory (TASK-0402)

Company Brain의 표준 Memory는 `scope / scopeId / key / value / description` 기반의
**AI용 구조화 설정 저장소**입니다. 같은 `(scope, scopeId, key)`는 한 건만 존재하며
value는 JSON입니다 — [docs/architecture/memory.md](docs/architecture/memory.md)

- `scope`(Enum): `GLOBAL · COMPANY · PROJECT · PRODUCT` — GLOBAL/COMPANY는 scopeId
  없이, PROJECT/PRODUCT는 실존하는 projectId/productId를 scopeId로 요구합니다.

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/memory` | `{ scope, scopeId?, key, value, description? }` 저장 (중복 key 400) |
| `GET` | `/memory?scope=&scopeId=` | 목록 (필터 선택, 최신순) |
| `GET` | `/memory/:memoryId` | 단건 |
| `PATCH` | `/memory/:memoryId` | `{ value?, description? }` 수정 — scope/key는 불변 |
| `DELETE` | `/memory/:memoryId` | 삭제 (204) |

### ProjectMemory (구 Memory, TASK-0307 — 보존)

기존 프로젝트 메모형 기억은 `ProjectMemory`로 개칭해 그대로 동작합니다
(테이블 `project_memories`로 데이터 보존, API 경로 동일):
`POST/GET /projects/:projectId/memories` · `GET/PATCH/DELETE …/memories/:memoryId`

## Company Brain Query (TASK-0403)

AI가 Company Brain을 한 번에 조회하는 진입점입니다. 조회 순서는
**Memory → Knowledge → Decision → SOP** 로 고정됩니다 —
[docs/architecture/company-brain.md](docs/architecture/company-brain.md)

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/company-brain/query` | `{ query, scope?, scopeId?, limit? }` → 고정 순서 4개 섹션 응답 |

## READY Validation (TASK-0404)

CompanyBrainService로 Knowledge/Memory/Decision/SOP를 읽어 READY 전환 가능
여부를 **PASS / WARNING / FAIL** 3단계로 판정합니다 (전체 판정 = 최악 값) —
[docs/architecture/ready-validation.md](docs/architecture/ready-validation.md)

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/projects/:projectId/ready-validation` | `{ productObjectVersion? }` → 판정 + 6개 검사 상세 |

- 금지어 검사: Memory `{ scope: "GLOBAL", key: "banned-words", value: [...] }` 기반
- 검증은 판단만 — 실제 전이는 기존 `PATCH …/product-object/:version/status` 사용

## Knowledge (TASK-0401)

회사의 공식 지식(규칙·정책·가이드)을 보존합니다. 프로젝트별 경험(Memory)과 달리
**회사 전역**이며, 이후 Company Brain Query·READY 검증의 원천이 됩니다 —
[docs/architecture/knowledge.md](docs/architecture/knowledge.md)

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/knowledge` | `{ title, content, category? }` 생성 |
| `GET` | `/knowledge` | 목록 (최신순) |
| `GET` | `/knowledge/:knowledgeId` | 단건 |
| `PATCH` | `/knowledge/:knowledgeId` | 부분 수정 |
| `DELETE` | `/knowledge/:knowledgeId` | 삭제 (204) |

- `category`(Enum, 선택): `RULE · POLICY · GUIDE · BRAND · LEGAL · QUALITY · FAQ · OTHER`

오류: `400` 필수 필드(title/content) 누락·공백·Enum 외 category, `404` 지식 없음.

## Product (TASK-0203)

업로드된 사진(들)을 묶어 Product Object를 생성합니다.
웹에서는 업로드 완료 후 "Product 생성" 버튼 → `/products` 목록 · `/products/[id]` 상세로 이어집니다.

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| `POST` | `/products` | `{ name?, description?, imageIds: string[] }` — 이미지 연결, 이름 미지정 시 OCR 첫 줄→파일명→기본값 순으로 자동 생성 |
| `GET` | `/products?take=20` | 목록 (썸네일·사진 수 포함) |
| `GET` | `/products/:id` | 상세 (이미지 + OCR 결과 포함) |
| `PATCH` | `/products/:id` | `{ name?, description? }` 수정 |
| `DELETE` | `/products/:id` | 삭제 (이미지는 연결만 해제) |

오류: `400` 잘못된 이름/존재하지 않는 이미지/이미 다른 상품에 연결된 이미지, `404` 상품 없음.

## Prisma

- 스키마: `apps/api/prisma/schema.prisma`
- 연결 문자열: `DATABASE_URL` (기본값 `postgresql://postgres:postgres@localhost:5432/acos`)

```bash
pnpm docker:up                 # PostgreSQL 기동
cp .env.example apps/api/.env  # 환경 변수 준비
pnpm prisma:migrate            # 마이그레이션 생성/적용
```
